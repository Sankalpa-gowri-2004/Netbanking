/**
 * @license
 * Copyright (c) 2014, 2025, Oracle.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * @ignore
 */
define([
  'knockout',
  'ojs/ojcontext',
  'ojs/ojmodule-element-utils',
  'ojs/ojknockouttemplateutils',
  'ojs/ojcorerouter',
  'ojs/ojmodulerouter-adapter',
  'ojs/ojknockoutrouteradapter',
  'ojs/ojurlparamadapter',
  'ojs/ojresponsiveutils',
  'ojs/ojresponsiveknockoututils',
  'ojs/ojarraydataprovider',
  'ojs/ojdrawerpopup',
  'ojs/ojmodule-element',
  'ojs/ojknockout'
], function (
  ko,
  Context,
  moduleUtils,
  KnockoutTemplateUtils,
  CoreRouter,
  ModuleRouterAdapter,
  KnockoutRouterAdapter,
  UrlParamAdapter,
  ResponsiveUtils,
  ResponsiveKnockoutUtils,
  ArrayDataProvider
) {
  function ControllerViewModel() {
    const self = this;
    this.KnockoutTemplateUtils = KnockoutTemplateUtils;

    // Accessibility announcement handler
    this.manner = ko.observable('polite');
    this.message = ko.observable();
    const announcementHandler = (event) => {
      this.message(event.detail.message);
      this.manner(event.detail.manner);
    };
    document.getElementById('globalBody').addEventListener('announce', announcementHandler, false);

    // Responsive design
    const smQuery = ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
    this.smScreen = ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
    const mdQuery = ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP);
    this.mdScreen = ResponsiveKnockoutUtils.createMediaQueryObservable(mdQuery);

    /**
     * ROUTER CONFIGURATION
     * ---------------------
     * We’ll define all routes including login/signup/otp
     * The app will start with login as the default route
     */
    let navData = [
      { path: '', redirect: 'login' },
      { path: 'login', detail: { label: 'Login', iconClass: 'oj-ux-ico-lock' } },
      { path: 'otp', detail: { label: 'OTP', iconClass: 'oj-ux-ico-key' } },
      { path: 'signup', detail: { label: 'Signup', iconClass: 'oj-ux-ico-contact' } },
      // Customer routes
      { path: 'accounts', detail: { label: 'Accounts', iconClass: 'oj-ux-ico-bank', role: 'CUSTOMER' } },
      // { path: 'account-details', detail: { label: 'Account Details', iconClass: 'oj-ux-ico-bank', role: 'CUSTOMER' } },
      { path: 'branches', detail: { label: 'Branches', iconClass: 'oj-ux-ico-map', role: 'CUSTOMER' } },
      { path: 'create-account', detail: { label: 'Create Account', iconClass: 'oj-ux-ico-plus', role: 'CUSTOMER' } },
      { path: 'transaction', detail: { label: 'Transaction', iconClass: 'oj-ux-ico-transfer', role: 'CUSTOMER' } },
      { path: 'transaction-history', detail: { label: 'Transaction History', iconClass: 'oj-ux-ico-history', role: 'CUSTOMER' } },
      { path: 'cards', detail: { label: 'Cards', iconClass: 'oj-ux-ico-credit-card', role: 'CUSTOMER' } },
      // { path: 'bills', detail: { label: 'Bills', iconClass: 'oj-ux-ico-receipt', role: 'CUSTOMER' } },
      { path: 'view-loans', detail: { label: 'Loans', iconClass: 'oj-ux-ico-home', role: 'CUSTOMER' } },
      { path: 'apply-loan', detail: { label: 'Apply Loan', iconClass: 'oj-ux-ico-plus', role: 'CUSTOMER' } },
      // Admin routes
      { path: 'admindashboards', detail: { label: 'Admin Dashboard', iconClass: 'oj-ux-ico-dashboard', role: 'ADMIN' } },
      { path: 'adminaccount', detail: { label: 'Manage Accounts', iconClass: 'oj-ux-ico-bank', role: 'ADMIN' } },
      { path: 'adminbranches', detail: { label: 'Manage Branches', iconClass: 'oj-ux-ico-map', role: 'ADMIN' } },
      { path: 'admincards', detail: { label: 'Manage Cards', iconClass: 'oj-ux-ico-credit-card', role: 'ADMIN' } },
      { path: 'adminloans', detail: { label: 'Manage Loans', iconClass: 'oj-ux-ico-home', role: 'ADMIN' } },
      // { path: 'transferpayments', detail: { label: 'Transfers', iconClass: 'oj-ux-ico-exchange' } },
      // Feature routes (not shown in top nav)
      
    ];

    // Router setup
    let router = new CoreRouter(navData, {
      urlAdapter: new UrlParamAdapter()
    });
    router.sync();

    // Expose router globally for programmatic navigation from view models
    window.appRouter = router;
    
    // Test router function
    window.testRouter = function(path) {
      console.log('Testing router with path:', path);
      console.log('Current URL before navigation:', window.location.href);
      router.go({ path: path });
      console.log('Current URL after navigation:', window.location.href);
    };

    // Module router adapter
    this.moduleAdapter = new ModuleRouterAdapter(router);
    this.selection = new KnockoutRouterAdapter(router);

    // Function to get current user role
    this.getCurrentUserRole = function() {
      const user = localStorage.getItem('user');
      if (user) {
        try {
          const userObj = JSON.parse(user);
          const role = userObj.role || 'CUSTOMER';
          console.log('User role:', role); // Debug log
          return role;
        } catch (e) {
          console.error('Error parsing user data:', e); // Debug log
          return 'CUSTOMER';
        }
      }
      return 'CUSTOMER';
    };

    // Data provider for navigation drawer (role-based filtering)
    this.navDataProvider = ko.observable(new ArrayDataProvider([], { keyAttributes: 'path' }));
    
    // Function to update navigation data
    this.updateNavigationData = function() {
      const isAuth = this.isAuthenticated();
      
      if (!isAuth) {
        this.navDataProvider(new ArrayDataProvider([], { keyAttributes: 'path' }));
        return;
      }
      
      const currentRole = this.getCurrentUserRole();
      const filteredNavData = navData.filter((r) => {
        // Exclude auth pages
        if (['', 'login', 'otp', 'signup'].includes(r.path)) {
          return false;
        }
        // Show only routes that match the current user's role
        const routeRole = r.detail && r.detail.role;
        const shouldShow = routeRole === currentRole;
        return shouldShow;
      });
      
      console.log('Filtered navigation items:', filteredNavData.map(r => r.path)); // Debug log
      this.navDataProvider(new ArrayDataProvider(filteredNavData, { keyAttributes: 'path' }));
    };
    

    // Drawer
    this.sideDrawerOn = ko.observable(false);
    this.mdScreen.subscribe(() => {
      this.sideDrawerOn(false);
    });

    this.toggleDrawer = () => {
      this.sideDrawerOn(!this.sideDrawerOn());
    };
    
    // Navigation click handler
    this.handleNavigationClick = (event) => {
      console.log('Navigation click event:', event); // Debug log
      console.log('Event detail:', event.detail); // Debug log
      
      // Try different ways to get the selected item
      const selectedItem = event.detail.value || event.detail.selectedValue || event.detail;
      console.log('Selected item:', selectedItem); // Debug log
      
      if (selectedItem && selectedItem.path) {
        console.log('Navigating to:', selectedItem.path); // Debug log
        router.go({ path: selectedItem.path });
        // Close drawer on mobile
        this.sideDrawerOn(false);
      } else if (selectedItem && typeof selectedItem === 'string') {
        // If selectedItem is just a string path
        console.log('Navigating to string path:', selectedItem); // Debug log
        router.go({ path: selectedItem });
        this.sideDrawerOn(false);
      } else {
        console.log('No valid path found in selected item:', selectedItem); // Debug log
      }
    };

    // Header info
    this.appName = ko.observable('Banking App');
    this.userLogin = ko.observable('');
    
    // Set user login name from stored user data
    this.setUserLoginName = function() {
      const user = localStorage.getItem('user');
      if (user) {
        try {
          const userObj = JSON.parse(user);
          this.userLogin(userObj.username || userObj.email || 'User');
        } catch (e) {
          this.userLogin('User');
        }
      }
    };
    
    // Logout functionality
    this.logout = function() {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      localStorage.removeItem('email');
      router.go('login');
    };
    
    // Handle user menu actions
    this.handleUserMenuAction = function(event) {
      if (event.detail.value === 'out') {
        this.logout();
      }
      // Handle other menu actions as needed
    };

    /**
     * Show nav drawer only when user is authenticated
     * Check token in localStorage
     */
    this.isAuthenticated = ko.computed(() => {
      const authenticated = !!localStorage.getItem('token');
      if (authenticated) {
        this.setUserLoginName();
      }
      return authenticated;
    });
    
    // Update navigation when authentication status changes
    this.isAuthenticated.subscribe(() => {
      this.updateNavigationData();
    });
    
    // Initial navigation update
    this.updateNavigationData();

    // Control visibility of navigation UI (hide on auth pages)
    this.showNav = ko.computed(() => {
      // Prefer Knockout adapter's observable path for reactivity
      let routeId;
      if (this.selection && this.selection.path && typeof this.selection.path === 'function') {
        routeId = this.selection.path();
      } else if (router && router.currentState) {
        // Fallback: some router versions expose currentState as a plain object
        routeId = router.currentState.id;
      }
      const isAuthPage = ['login', 'otp', 'signup'].includes(routeId);
      const isAuthenticated = this.isAuthenticated();
      const shouldShowNav = isAuthenticated && !isAuthPage;
      return shouldShowNav;
    });

    // Watch for route changes: If user is not logged in, prevent protected route access
    router.currentState.subscribe((state) => {
      console.log('Router state changed to:', state.id); // Debug log
      console.log('Current URL:', window.location.href); // Debug log
      
      const customerRoutes = ['accounts', 'account-details', 'branches', 'create-account', 'transaction', 'transaction-history', 'cards', 'bills', 'view-loans', 'apply-loan', 'transferpayments'];
      const adminRoutes = ['admindashboards', 'adminaccount', 'adminbranches', 'admincards', 'adminloans'];
      const protectedRoutes = [...customerRoutes, ...adminRoutes];
      
      if (!self.isAuthenticated() && protectedRoutes.includes(state.id)) {
        router.go('login');
        return;
      }
      
      // Check role-based access for admin routes
      if (self.isAuthenticated() && adminRoutes.includes(state.id)) {
        const currentRole = self.getCurrentUserRole();
        if (currentRole !== 'ADMIN') {
          // Redirect to appropriate dashboard based on role
          const redirectPath = currentRole === 'ADMIN' ? 'admindashboards' : 'accounts';
          router.go(redirectPath);
        }
      }
    });

    // // // Footer
    // this.footerLinks = [
    //   { name: 'About Oracle', id: 'aboutOracle', linkTarget: 'http://www.oracle.com/us/corporate/index.html#menu-about' },
    //   { name: 'Contact Us', id: 'contactUs', linkTarget: 'http://www.oracle.com/us/corporate/contact/index.html' },
    //   { name: 'Legal Notices', id: 'legalNotices', linkTarget: 'http://www.oracle.com/us/legal/index.html' },
    //   { name: 'Terms Of Use', id: 'termsOfUse', linkTarget: 'http://www.oracle.com/us/legal/terms/index.html' },
    //   { name: 'Your Privacy Rights', id: 'yourPrivacyRights', linkTarget: 'http://www.oracle.com/us/legal/privacy/index.html' }
    // ];
  }

  Context.getPageContext().getBusyContext().applicationBootstrapComplete();
  return new ControllerViewModel();
});
