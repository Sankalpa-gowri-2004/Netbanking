define(['ojs/ojcore', 'jquery'], function (oj, $) {
  const BASE_URL = 'http://localhost:7777/api/v1';
  const AUTH_URL = `${BASE_URL}/auth`;
  const ACCOUNT_URL = `${BASE_URL}/accounts`;
  const BRANCHES_URL = `${BASE_URL}/branches`;
  const CARDS_URL = `${BASE_URL}/cards`;
  const LOANS_URL = `${BASE_URL}/loans`;

  // Auth methods
  function loginFirstFactor(email, password) {
    return $.ajax({
      url: `${AUTH_URL}/login`,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ email, password }),
    });
  }

  function loginSecondFactor(email, otp) {
    return $.ajax({
      url: `${AUTH_URL}/verify-otp`,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ email, otp }),
    });
  }

  function signup(username, email, password) {
    return $.ajax({
      url: `${AUTH_URL}/register`,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ username, email, password }),
    });
  }

  // Account methods
  function createAccount(accountData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${ACCOUNT_URL}`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(accountData),
    });
  }

  function getUserAccounts() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    const userObject = JSON.parse(user);
    const id = userObject.id;
    // console.log();
    return $.ajax({
      url: `${ACCOUNT_URL}/${id}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function getAccountDetails(accountId) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/accounts/${accountId}/detailed`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function getMiniStatement(accountNumber) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${ACCOUNT_URL}/mini-statement/${accountNumber}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  // Branch methods
  function getBranches() {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BRANCHES_URL}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  // Card methods
  function getUserCards() {
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    const userObj = userStr ? JSON.parse(userStr) : null;
    const userId = userObj && userObj.id != null ? userObj.id : null;
    return $.ajax({
      url: `${CARDS_URL}/${userId}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function blockCard(cardNumber) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${CARDS_URL}/block/${cardNumber}`,
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function requestCard(cardType) {
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    const userObj = userStr ? JSON.parse(userStr) : null;
    const userId = userObj && userObj.id != null ? userObj.id : null;
    return $.ajax({
      url: `${CARDS_URL}/request/${userId}`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify({ cardType: cardType }),
    });
  }

  // Loan methods
  function getUserLoans() {
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    const userObj = userStr ? JSON.parse(userStr) : null;
    const userId = userObj && userObj.id != null ? userObj.id : null;
    return $.ajax({
      url: `${LOANS_URL}/user/${userId}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function createLoan(loanData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${LOANS_URL}`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(loanData),
    });
  }

  // Transaction methods
  function transferMoney(transferData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/transactions/transfer`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(transferData),
    });
  }

  function searchTransactions(filterCriteria) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/transactions/search`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(filterCriteria || {}),
    });
  }

  // function getUserTransactions(filterCriteria) {
  //   const token = localStorage.getItem('token');
  //   const accountNumber = localStorage.getItem('accountNumber');
  //   return $.ajax({
  //     url: `${BASE_URL}/transactions/from/${accountNumber}`,
  //     method: 'GET',
  //     contentType: 'application/json',
  //     headers: { 'Authorization': `Bearer ${token}` }
  //     // data: JSON.stringify(filterCriteria || {}),
  //   });
  // }

  function getUserTransactions(filterCriteria = {}) {
  const token = localStorage.getItem('token');
  const accountNumber = localStorage.getItem('accountNumber');

  const queryParams = $.param(filterCriteria);
  const url = queryParams
    ? `${BASE_URL}/transactions/from/${accountNumber}?${queryParams}`
    : `${BASE_URL}/transactions/from/${accountNumber}`;

  return $.ajax({
    url: url,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${token}` },
  });
}

  // Admin methods
  function getAdminDashboard() {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/dashboard`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function getAdminAccounts(filters = {}) {
    const token = localStorage.getItem('token');
    
    // Build query parameters
    const params = new URLSearchParams();
    if (filters.type) {
      params.append('type', filters.type);
    }
    if (filters.branch) {
      params.append('branch', filters.branch);
    }
    if (filters.status) {
      params.append('status', filters.status);
    }
    if (filters.holderName) {
      params.append('holderName', filters.holderName);
    }

    let url = `${BASE_URL}/admin/accounts`;
    if (params.toString()) {
      url += '?' + params.toString();
    }

    return $.ajax({
      url: url,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function getAdminCards() {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/cards`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function getAdminLoans() {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/loans`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
    });
  }

  function updateBranch(ifscCode, branchData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/branch/${ifscCode}`,
      method: 'PATCH',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(branchData),
    });
  }

  function createBranch(branchData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/branches`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(branchData),
    });
  }

  function createCustomer(customerData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/account`,
      method: 'POST',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(customerData),
    });
  }

  function updateAccount(accountNumber, accountData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/account/${accountNumber}`,
      method: 'PATCH',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(accountData),
    });
  }

  function updateCard(cardNumber, cardData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/card/${cardNumber}`,
      method: 'PATCH',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(cardData),
    });
  }

  function updateLoan(loanId, loanData) {
    const token = localStorage.getItem('token');
    return $.ajax({
      url: `${BASE_URL}/admin/loan/${loanId}`,
      method: 'PATCH',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${token}` },
      data: JSON.stringify(loanData),
    });
  }
    // Loan repayment methods
    function makeLoanRepayment(loanId, amountPaid) {
      const token = localStorage.getItem('token');
      return $.ajax({
        url: `${LOANS_URL}/${loanId}/repayments`,
        method: 'POST',
        contentType: 'application/json',
        headers: { 'Authorization': `Bearer ${token}` },
        data: JSON.stringify({
          amountPaid: amountPaid,
          paymentMode: 'NET_BANKING'
        }),
      });
    }
  
    function getLoanRepayments(loanId) {
      const token = localStorage.getItem('token');
      return $.ajax({
        url: `${LOANS_URL}/${loanId}/repayments`,
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` },
      });
    }
  


    

  return {
    // Auth methods
    loginFirstFactor,
    loginSecondFactor,
    signup,
    // Account methods
    createAccount,
    getUserAccounts,
    getAccountDetails,
    getMiniStatement,
    getBranches,
    getUserCards,
    blockCard,
    requestCard,
    // Loan methods
    getUserLoans,
    createLoan,
    // Transaction methods
    transferMoney,
    searchTransactions,
    // Admin methods
    getAdminDashboard,
    getAdminAccounts,
    getAdminCards,
    getAdminLoans,
    updateBranch,
    createBranch,
    createCustomer,
    updateAccount,
    updateCard,
    updateLoan,
    makeLoanRepayment,
    getLoanRepayments,
    getUserTransactions
  };
});
