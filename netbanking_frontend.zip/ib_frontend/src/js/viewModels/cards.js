// viewmodels/cards.js
define(['knockout', 'services/authService', 'ojs/ojdialog', 'ojs/ojknockout'], function(ko, authService) {
  function CardsViewModel() {
    var self = this;

    // user
    var userStr = localStorage.getItem('user');
    var userObj = userStr ? JSON.parse(userStr) : { name: 'User' };
    self.userName = ko.observable(userObj.name || 'User');

    // cards data
    self.cards = ko.observableArray([]);
    self.selectedCardId = ko.observable(null);
    self.selectedCard = ko.computed(function(){
      return self.cards().find(function(c){ return c.cardId === self.selectedCardId(); });
    });

    self.selectCard = function(id) {
      self.selectedCardId(id);
      setTimeout(function(){
        var dlg = document.getElementById('cardDetailsDialog');
        if (dlg && typeof dlg.open === 'function') dlg.open();
      }, 0);
    };

    // Card actions
    self.blockCard = function() {
      var c = self.selectedCard();
      if (!c) return;
      authService.blockCard(c.cardNumber)
        .done(function(){
          c.status = 'BLOCKED';
          self.cards(self.cards().slice());
        })
        .fail(function(){
          alert('Failed to block card');
        });
    };

    self.unblockCard = function() {
      var c = self.selectedCard();
      if (!c) return;
      authService.updateCard(c.cardNumber, { status: 'ACTIVE' })
        .done(function(){
          c.status = 'ACTIVE';
          self.cards(self.cards().slice());
        })
        .fail(function(){
          alert('Failed to unblock card');
        });
    };

    self.reportLostCard = function() {
      var card = self.selectedCard();
      if (!card) { return; }
      var confirmed = window.confirm('Are you sure you want to report this card as lost/stolen and block it?');
      if (!confirmed) { return; }
      authService.blockCard(card.cardNumber)
        .done(function(){
          card.status = 'BLOCKED';
          self.cards(self.cards().slice());
          alert('Card successfully blocked');
        })
        .fail(function(err){
          alert('Failed to block card');
        });
    };

    // Request new card modal state
    self.showAddCardDialog = ko.observable(false);
    self.newCard = {
      cardType: ko.observable('')
    };
    self.isRequesting = ko.observable(false);
    self.requestMessage = ko.observable('');
    self.canRequestCard = ko.observable(false);

    // validation updater
    self.updateCanRequestCard = function() {
      var cardTypeRaw = (self.newCard.cardType() || '').trim();
      var upper = (cardTypeRaw || '').toUpperCase();
      var isValidType = upper === 'DEBIT' || upper === 'CREDIT';
      var notRequesting = !self.isRequesting();
      var canRequest = isValidType && notRequesting;
      console.log('updateCanRequestCard', { cardTypeRaw, upper, isValidType, notRequesting, canRequest });
      self.canRequestCard(canRequest);
    };

    // subscriptions
    self.newCard.cardType.subscribe(function(){ self.updateCanRequestCard(); });
    self.isRequesting.subscribe(function(){ self.updateCanRequestCard(); });

    // open/close dialog helpers
    self.openAddCardDialog = function() {
      console.log('Opening add card dialog');
      // reset form
      self.newCard.cardType('');
      self.requestMessage('');
      self.isRequesting(false);
      self.canRequestCard(false);
      self.updateCanRequestCard();

      setTimeout(function() {
        var dlg = document.getElementById('addCardDialog');
        if (dlg && typeof dlg.open === 'function') dlg.open();
        var input = document.getElementById('cardTypeInput');
        if (input) input.focus();
      }, 50);
    };

    self.closeAddCardDialog = function() {
      var dlg = document.getElementById('addCardDialog');
      if (dlg && typeof dlg.close === 'function') dlg.close();

      self.showAddCardDialog(false);
      self.requestMessage('');
      self.newCard.cardType('');
      self.isRequesting(false);
      self.updateCanRequestCard();
    };

    // robust requestCard (handles jQuery deferreds and native promises)
    self.requestCard = function() {
      console.log('Request card clicked', {
        canRequestCard: self.canRequestCard(),
        cardType: self.newCard.cardType(),
        isRequesting: self.isRequesting()
      });

      if (!self.canRequestCard()) {
        self.requestMessage('Please enter DEBIT or CREDIT');
        return;
      }

      self.isRequesting(true);
      self.requestMessage('');

      var cardType = (self.newCard.cardType() || '').toUpperCase();

      var p;
      try {
        p = authService.requestCard(cardType);
      } catch (syncErr) {
        console.error('authService.requestCard threw', syncErr);
        self.requestMessage('Request failed (client error).');
        self.isRequesting(false);
        self.updateCanRequestCard();
        return;
      }

      if (!p) {
        console.error('authService.requestCard returned falsy', p);
        self.requestMessage('Request service unavailable.');
        self.isRequesting(false);
        self.updateCanRequestCard();
        return;
      }

      // jQuery Deferred
      if (typeof p.done === 'function') {
        p.done(function(response) {
          console.log('Card request success (done):', response);
          self.requestMessage('Card request submitted successfully!');
          setTimeout(function() {
            self.closeAddCardDialog();
            self.fetchCards();
          }, 900);
        }).fail(function(err) {
          console.log('Card request failed (fail):', err);
          self.requestMessage('Failed to request card. Please try again.');
        }).always(function() {
          self.isRequesting(false);
          self.updateCanRequestCard();
        });
        return;
      }

      // native Promise
      if (typeof p.then === 'function') {
        p.then(function(response) {
          console.log('Card request success (then):', response);
          self.requestMessage('Card request submitted successfully!');
          setTimeout(function() {
            self.closeAddCardDialog();
            self.fetchCards();
          }, 900);
        }).catch(function(err) {
          console.log('Card request failed (catch):', err);
          self.requestMessage('Failed to request card. Please try again.');
        }).finally(function() {
          self.isRequesting(false);
          self.updateCanRequestCard();
        });
        return;
      }

      // fallback
      console.error('requestCard returned unsupported value:', p);
      self.requestMessage('Request service unavailable.');
      self.isRequesting(false);
      self.updateCanRequestCard();
    };

    // Fetch cards from service
    self.isLoading = ko.observable(false);
    self.error = ko.observable('');
    self.fetchCards = function(){
      self.isLoading(true);
      self.error('');
      authService.getUserCards()
        .done(function(res){
          var mapped = (res || []).map(function(c){
            return {
              cardId: c.cardId,
              cardNumber: c.cardNumber,
              cardType: c.cardType,
              expiryDate: c.expiryDate,
              status: c.status,
              accountId: c.accountId,
              holderName: self.userName()
            };
          });
          self.cards(mapped);
          if (mapped.length > 0) {
            self.selectedCardId(mapped[0].cardId);
          } else {
            self.selectedCardId(null);
          }
        })
        .fail(function(err){
          console.error('fetchCards failed', err);
          self.error((err && err.message) ? err.message : 'Failed to load cards');
          self.cards([]);
          self.selectedCardId(null);
        })
        .always(function(){
          self.isLoading(false);
        });
    };

    // OJET lifecycle
    self.connected = function(){
      self.fetchCards();
    };
  }

  return CardsViewModel;
});
