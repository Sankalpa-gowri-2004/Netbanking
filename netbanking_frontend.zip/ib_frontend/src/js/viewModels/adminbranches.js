/**
 * Branches ViewModel for JET Bank Admin Portal
 */
define(['knockout', 'services/authService'], function(ko, authService) {
    function Branch(data) {
        this.id = data.id;
        this.ifscCode = data.ifscCode;
        this.branchName = data.branchName;
        this.address = data.address;
        this.city = data.city;
        this.state = data.state;
        this.contactNumber = data.contactNumber;
    }

    function BranchesViewModel() {
        var self = this;

        self.filterText = ko.observable("");
        self.isLoading = ko.observable(false);
        self.errorMessage = ko.observable("");
        self.isSaving = ko.observable(false);
        self.saveErrorMessage = ko.observable("");
        self.saveSuccessMessage = ko.observable("");

        // Branches data from API
        self.allBranches = ko.observableArray([]);

        // Load branches from API
        self.loadBranches = function() {
            self.isLoading(true);
            self.errorMessage("");
            
            authService.getBranches()
                .done(function(response) {
                    var branches = response.map(function(branchData) {
                        return new Branch(branchData);
                    });
                    self.allBranches(branches);
                })
                .fail(function(xhr, status, error) {
                    console.error('Error loading branches:', error);
                    self.errorMessage('Failed to load branches. Please try again.');
                })
                .always(function() {
                    self.isLoading(false);
                });
        };

        // Initialize data
        self.loadBranches();

        // Filtering
        self.filteredBranches = ko.computed(function() {
            var filterText = self.filterText().toLowerCase().trim();
            if (!filterText) return self.allBranches();
            return ko.utils.arrayFilter(self.allBranches(), function(b) {
                return (
                    b.ifscCode.toLowerCase().indexOf(filterText) > -1 ||
                    b.branchName.toLowerCase().indexOf(filterText) > -1 ||
                    b.city.toLowerCase().indexOf(filterText) > -1 ||
                    b.state.toLowerCase().indexOf(filterText) > -1
                );
            });
        });

        // Sorting
        self.sortColumn = ko.observable('ifscCode');
        self.sortAsc = ko.observable(true);
        self.sortBy = function(col) {
            if (self.sortColumn() === col) {
                self.sortAsc(!self.sortAsc());
            } else {
                self.sortColumn(col);
                self.sortAsc(true);
            }
        };
        self.sortedBranches = ko.computed(function() {
            var arr = self.filteredBranches().slice(0);
            var column = self.sortColumn();
            var asc = self.sortAsc();
            arr.sort(function(a, b) {
                var aVal = a[column];
                var bVal = b[column];
                if (typeof aVal === "number") {
                    return asc ? aVal - bVal : bVal - aVal;
                }
                return asc
                    ? aVal.toString().localeCompare(bVal.toString())
                    : bVal.toString().localeCompare(aVal.toString());
            });
            return arr;
        });

        // Paging
        self.pageSize = ko.observable(5);
        self.pageIndex = ko.observable(0);
        self.totalPages = ko.computed(function() {
            return Math.ceil(self.sortedBranches().length / self.pageSize());
        });
        self.pagedBranches = ko.computed(function() {
            var start = self.pageIndex() * self.pageSize();
            return self.sortedBranches().slice(start, start + self.pageSize());
        });
        self.nextPage = function() {
            if (self.pageIndex() < self.totalPages() - 1) self.pageIndex(self.pageIndex() + 1);
        };
        self.prevPage = function() {
            if (self.pageIndex() > 0) self.pageIndex(self.pageIndex() - 1);
        };
        self.filterText.subscribe(function() { self.pageIndex(0); });
        self.sortColumn.subscribe(function() { self.pageIndex(0); });
        self.sortAsc.subscribe(function() { self.pageIndex(0); });

        // Dialog/modal
        self.showBranchDialog = ko.observable(false);
        self.isEditMode = ko.observable(false);
        self.dialogBranch = ko.observable({
            id: "",
            ifscCode: "",
            branchName: "",
            address: "",
            city: "",
            state: "",
            contactNumber: ""
        });

        self.openAddBranch = function() {
            self.isEditMode(false);
            self.dialogBranch({
                id: "",
                ifscCode: "",
                branchName: "",
                address: "",
                city: "",
                state: "",
                contactNumber: ""
            });
            self.showBranchDialog(true);
        };
        self.editBranch = function(branch) {
            self.isEditMode(true);
            self.dialogBranch({
                id: branch.id,
                ifscCode: branch.ifscCode,
                branchName: branch.branchName,
                address: branch.address,
                city: branch.city,
                state: branch.state,
                contactNumber: branch.contactNumber
            });
            self.showBranchDialog(true);
        };
        self.saveBranch = function() {
            var branch = self.dialogBranch();
            if (!branch.ifscCode || !branch.branchName) {
                alert("IFSC Code and Branch Name are required.");
                return;
            }
            
            if (self.isEditMode()) {
                // Update existing branch via API
                self.isSaving(true);
                self.saveErrorMessage("");
                
                // Prepare data for API (exclude id and ifscCode from request body)
                var updateData = {
                    branchName: branch.branchName,
                    address: branch.address,
                    city: branch.city,
                    state: branch.state,
                    contactNumber: branch.contactNumber
                };
                
                authService.updateBranch(branch.ifscCode, updateData)
                    .done(function(response) {
                        // Update the branch in the local array
                        var idx = self.allBranches().findIndex(function(b) { return b.id === branch.id; });
                        if (idx > -1) {
                            self.allBranches.splice(idx, 1, new Branch(branch));
                        }
                        self.saveSuccessMessage('Branch updated successfully!');
                        self.closeDialog();
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.saveSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error updating branch:', error);
                        self.saveErrorMessage('Failed to update branch. Please try again.');
                    })
                    .always(function() {
                        self.isSaving(false);
                    });
            } else {
                // Create new branch via API
                self.isSaving(true);
                self.saveErrorMessage("");
                
                // Prepare data for API
                var createData = {
                    ifscCode: branch.ifscCode,
                    branchName: branch.branchName,
                    address: branch.address,
                    city: branch.city,
                    state: branch.state,
                    contactNumber: branch.contactNumber
                };
                
                authService.createBranch(createData)
                    .done(function(response) {
                        // Add the new branch to the local array
                        self.allBranches.unshift(new Branch(branch));
                        self.saveSuccessMessage('Branch created successfully!');
                        self.closeDialog();
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.saveSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error creating branch:', error);
                        self.saveErrorMessage('Failed to create branch. Please try again.');
                    })
                    .always(function() {
                        self.isSaving(false);
                    });
            }
        };
        self.closeDialog = function() {
            self.showBranchDialog(false);
        };
    }
    return new BranchesViewModel();
});
