define(['knockout', 'ojs/ojrouter', 'services/authService'], function (ko, Router, authService) {
  function OtpViewModel() {
    const self = this;

    self.email = localStorage.getItem('email');
    self.otp = ko.observable('');
    self.message = ko.observable('');

    self.verifyOtp = function () {
      authService
        .loginSecondFactor(self.email, self.otp())
        .then((response) => {
          if (response.success) {
            localStorage.setItem('token', response.token);
            localStorage.setItem('user', JSON.stringify(response));
            
            // Role-based routing after successful OTP verification
            const userRole = response.role;
            let redirectPath = 'accounts'; // Default for CUSTOMER role
            
            if (userRole === 'ADMIN') {
              redirectPath = 'admindashboards';
            }
            
            window.appRouter && window.appRouter.go({ path: redirectPath });
          } else {
            self.message('Invalid OTP');
          }
        })
        .catch((err) => self.message('Error: ' + err.responseText));
    };
  }

  return new OtpViewModel();
});
