define(['knockout', 'services/authService'], function(ko, authService) {
  function ApplyLoanViewModel(params) {
    var self = this;

    // User info
    self.userName = ko.observable(JSON.parse(localStorage.getItem('user')).name || 'User');

    // Form fields matching API requirements
    self.loanType = ko.observable('BIKE');
    self.principalAmount = ko.observable(10000);
    self.interestRate = ko.observable(3.5);
    self.tenureMonths = ko.observable(240);
    self.startDate = ko.observable('2025-01-01');

    // State management
    self.isSubmitting = ko.observable(false);
    self.message = ko.observable('');

    // EMI calculation based on actual interest rate
    self.estimatedEMI = ko.pureComputed(function() {
      var P = parseFloat(self.principalAmount()) || 0;
      var N = parseInt(self.tenureMonths()) || 1;
      var R = parseFloat(self.interestRate()) || 0; // annual interest rate
      var monthlyRate = R / (12 * 100); // convert to monthly decimal
      
      if (monthlyRate === 0) {
        return P / N; // Simple division if no interest
      }
      
      var emi = P * monthlyRate * Math.pow(1 + monthlyRate, N) / 
                (Math.pow(1 + monthlyRate, N) - 1);
      
      return emi ? '₹' + Math.round(emi).toLocaleString('en-IN') : '₹0';
    });

    // Validation
    self.canSubmit = ko.pureComputed(function() {
      return self.principalAmount() > 0 && 
             self.interestRate() > 0 && 
             self.tenureMonths() > 0 && 
             self.startDate() && 
             !self.isSubmitting();
    });

    self.submitLoan = function() {
      if (!self.canSubmit()) {
        self.message('Please fill in all required fields correctly.');
        return;
      }

      self.isSubmitting(true);
      self.message('');

      // Get user ID from localStorage
      var userStr = localStorage.getItem('user');
      var userObj = userStr ? JSON.parse(userStr) : null;
      var userId = userObj && userObj.id != null ? userObj.id : null;

      if (!userId) {
        self.message('User not found. Please login again.');
        self.isSubmitting(false);
        return;
      }

      // Prepare data for API
      var loanData = {
        userId: userId,
        loanType: self.loanType(),
        principalAmount: parseFloat(self.principalAmount()),
        interestRate: parseFloat(self.interestRate()),
        tenureMonths: parseInt(self.tenureMonths()),
        startDate: self.startDate()
      };

      console.log('Submitting loan data:', loanData);

      authService.createLoan(loanData)
        .then(function(response) {
          console.log('Loan created successfully:', response);
          self.message('Loan application submitted successfully!');
          
          // Reset form after successful submission
          setTimeout(function() {
            self.resetForm();
            if (window.router) {
              window.router.go('view-loans');
            }
          }, 2000);
        })
        .catch(function(error) {
          console.error('Error creating loan:', error);
          self.message('Failed to submit loan application. Please try again.');
        })
        .always(function() {
          self.isSubmitting(false);
        });
    };

    self.resetForm = function() {
      self.loanType('BIKE');
      self.principalAmount(10000);
      self.interestRate(3.5);
      self.tenureMonths(240);
      self.startDate('2025-01-01');
      self.message('');
    };

    // Initialize with current date
    self.connected = function() {
      var today = new Date();
      var dateString = today.toISOString().split('T')[0];
      self.startDate(dateString);
    };
  }

  return ApplyLoanViewModel;
});