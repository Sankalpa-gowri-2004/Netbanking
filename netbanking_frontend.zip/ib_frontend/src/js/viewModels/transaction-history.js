define(['knockout', 'services/authService'], function (ko, authService) {
  function TransactionHistoryViewModel(params) {
    var self = this;

    // ===== USER INFO =====
    const user = JSON.parse(localStorage.getItem('user')) || {};
    self.userName = ko.observable(user.name || 'User');
    self.initials = ko.pureComputed(() => self.userName().charAt(0).toUpperCase());
    self.accountInfo = ko.observable('A/C: ****1234');

    // ===== FILTERS =====
    self.type = ko.observable('');
    self.status = ko.observable('');
    self.fromDate = ko.observable('');
    self.toDate = ko.observable('');
    self.accountId = ko.observable('');

    // ===== OBSERVABLES =====
    self.transactions = ko.observableArray([]);
    self.isLoading = ko.observable(false);
    self.error = ko.observable('');

    // ===== FETCH TRANSACTIONS (with filters) =====
    self.fetchTransactions = function () {
      self.isLoading(true);
      self.error('');

      const userId = user.id;
      if (!userId) {
        self.error('User not found. Please log in again.');
        self.isLoading(false);
        return;
      }

      // Prepare filters
      const filters = {
        type: self.type(),
        status: self.status(),
        fromDate: self.fromDate(),
        toDate: self.toDate(),
        accountId: self.accountId()
      };

      console.log('📡 Fetching transactions with filters:', filters);

      authService.getUserTransactions(filters)
        .then(function (response) {
          console.log('✅ API response:', response);

          if (!response || response.length === 0) {
            self.transactions([]);
            self.error('No transactions found for this user.');
            return;
          }

          const mappedTransactions = response.map(function (txn) {
            return {
              transactionId: txn.transactionId,
              date: self.formatDate(txn.date),
              description: txn.description || '-',
              type: self.formatTransactionType(txn.type),
              amount: txn.amount ? Number(txn.amount) : 0,
              status: txn.status,
              formattedAmount: self.formatCurrency(txn.amount)
            };
          });

          self.transactions(mappedTransactions);
        })
        .catch(function (error) {
          console.error('❌ Error fetching transactions:', error);
          self.error('Failed to load transactions. Please try again later.');
          self.transactions([]);
        })
        .always(function () {
          self.isLoading(false);
        });
    };

    // ===== APPLY / CLEAR FILTERS =====
    self.applyFilter = function () {
      self.fetchTransactions();
    };

    self.clearFilters = function () {
      self.type('');
      self.status('');
      self.fromDate('');
      self.toDate('');
      self.accountId('');
      self.fetchTransactions();
    };

    self.retry = function () {
      self.fetchTransactions();
    };

    // ===== FORMATTERS =====
    self.formatDate = function (dateString) {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return date.toLocaleString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    };

    self.formatTransactionType = function (type) {
      if (!type) return 'N/A';
      switch (type.toUpperCase()) {
        case 'TRANSFER': return 'Transfer';
        case 'DEPOSIT': return 'Deposit';
        case 'WITHDRAWAL': return 'Withdrawal';
        case 'PAYMENT': return 'Payment';
        case 'CREDIT': return 'Credit';
        default: return type;
      }
    };

    self.formatCurrency = function (amount) {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2
      }).format(amount || 0);
    };

    // ===== SUMMARY COMPUTATIONS =====
    self.totalCredits = ko.pureComputed(() => {
      const total = self.transactions()
        .filter(t => ['DEPOSIT', 'CREDIT'].includes(t.type?.toUpperCase()))
        .reduce((sum, t) => sum + (t.amount || 0), 0);
      return self.formatCurrency(total);
    });

    self.totalDebits = ko.pureComputed(() => {
      const total = self.transactions()
        .filter(t => ['TRANSFER', 'WITHDRAWAL', 'PAYMENT'].includes(t.type?.toUpperCase()))
        .reduce((sum, t) => sum + (t.amount || 0), 0);
      return self.formatCurrency(total);
    });

    self.totalBalance = ko.pureComputed(() => {
      const total = self.transactions()
        .reduce((sum, t) => {
          const isCredit = ['DEPOSIT', 'CREDIT'].includes(t.type?.toUpperCase());
          return sum + (isCredit ? t.amount : -t.amount);
        }, 0);
      return self.formatCurrency(total);
    });

    // ===== PDF & PRINT =====
    self.exportPDF = function () {
      window.print();
    };

    self.printTransactions = function () {
      window.print();
    };

    // ===== INIT =====
    self.connected = function () {
      console.log('🌐 TransactionHistoryViewModel connected.');
      self.fetchTransactions();
    };
  }

  return TransactionHistoryViewModel;
});