define(['knockout', 'services/authService'], function(ko, authService) {
  function ViewLoansViewModel(params) {
    var self = this;

    // User info
    self.userName = ko.observable(JSON.parse(localStorage.getItem('user')).name || 'User');

    // Loans data
    self.loans = ko.observableArray([]);
    self.isLoading = ko.observable(false);
    self.error = ko.observable('');

    // Fetch loans from API
    self.fetchLoans = function() {
      self.isLoading(true);
      self.error('');
      
      authService.getUserLoans()
        .then(function(response) {
          console.log('Loans API response:', response);
          
          // Map API response to display format
          var mappedLoans = (response || []).map(function(loan) {
            return {
              id: loan.id,
              type: self.formatLoanType(loan.loanType),
              principal: self.formatCurrency(loan.principalAmount),
              balance: self.formatCurrency(loan.remainingAmount),
              emi: self.calculateEMI(loan.principalAmount, loan.interestRate, loan.tenureMonths),
              dueDate: self.formatDate(loan.startDate),
              status: loan.status,
              interestRate: loan.interestRate,
              tenureMonths: loan.tenureMonths,
              startDate: loan.startDate,
              userId: loan.userId
            };
          });
          
          self.loans(mappedLoans);
        })
        .catch(function(error) {
          console.error('Error fetching loans:', error);
          self.error('Failed to load loans. Please try again.');
          self.loans([]);
        })
        .always(function() {
          self.isLoading(false);
        });
    };

    // Helper functions
    self.formatLoanType = function(loanType) {
      switch(loanType) {
        case 'HOME_LOAN': return 'Home';
        case 'CAR_LOAN': return 'Car';
        case 'PERSONAL_LOAN': return 'Personal';
        default: return loanType;
      }
    };

    self.formatCurrency = function(amount) {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(amount);
    };

    self.calculateEMI = function(principal, rate, tenure) {
      if (!principal || !rate || !tenure) return '₹0';
      
      var monthlyRate = rate / (12 * 100);
      var emi = principal * monthlyRate * Math.pow(1 + monthlyRate, tenure) / 
                (Math.pow(1 + monthlyRate, tenure) - 1);
      
      return self.formatCurrency(emi);
    };

    self.formatDate = function(dateString) {
      if (!dateString) return 'N/A';
      var date = new Date(dateString);
      return date.toLocaleDateString('en-IN');
    };

    self.viewLoanDetails = function(loan) {
      console.log('Viewing details for loan:', loan);
      alert('Viewing details for Loan ID: ' + loan.id + '\nType: ' + loan.type + '\nPrincipal: ' + loan.principal);
    };

    self.downloadSummary = function(loan) {
      alert('Downloading summary for Loan ID: ' + loan.id);
    };

    self.applyNewLoan = function() {
      if (window.router) {
        window.router.go('apply-loan');
      }
    };

    // Initialize data when component loads
    self.connected = function() {
      self.fetchLoans();
    };
  }

  return ViewLoansViewModel;
});
