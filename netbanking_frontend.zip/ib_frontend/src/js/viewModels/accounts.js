define(['knockout', 'services/authService', 'ojs/ojarraydataprovider', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojdialog', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojinputnumber'],
  function (ko, authService, ArrayDataProvider) {

    function AccountsViewModel() {
      var self = this;

      self.userName = ko.observable(localStorage.getItem('firstName') || 'User');

      // Accounts data
      self.accounts = ko.observableArray([]);

      self.selectedAccountId = ko.observable(null);
      self.selectedAccount = ko.computed(() => {
        return self.accounts().find(function(acc) { return acc.accountNumber === self.selectedAccountId(); });
      });

		// Details modal state
		self.isDetailsLoading = ko.observable(false);
		self.detailsError = ko.observable('');
		self.accountDetails = ko.observable({});

		self.selectAccount = function(account) {
			if (!account) { return; }
			self.selectedAccountId(account.accountNumber);
			if (account.id != null) {
				self.fetchAccountDetails(account.id);
			}
		};

		self.fetchAccountDetails = function(accountId) {
			self.isDetailsLoading(true);
			self.detailsError('');
			authService.getAccountDetails(accountId)
				.then(function(details) {
					self.accountDetails(details || {});
					var dlg = document.getElementById('accountDetailsDialog');
					if (dlg && typeof dlg.open === 'function') {
						dlg.open();
					}
				})
				.catch(function(err) {
					self.detailsError((err && err.message) ? err.message : 'Failed to load account details');
				})
				.always(function() {
					self.isDetailsLoading(false);
				});
		};

		self.closeDetailsDialog = function() {
			var dlg = document.getElementById('accountDetailsDialog');
			if (dlg && typeof dlg.close === 'function') {
				dlg.close();
			}
		};

      // Navigation function
      self.goToCreateAccount = function() {
        if (window.appRouter) {
          window.appRouter.go({ path: 'create-account' });
        }
      };

      // Fetch accounts from backend
      self.fetchAccounts = function() {
        authService.getUserAccounts()
          .then(function(response) {
            var ownerName = localStorage.getItem('firstName') || 'User';
            localStorage.setItem('accountNumber', (response[0] && response[0].accountNumber) || 'Not Able to get');

			var accounts = (response || []).map(function(a, idx) {
              return {
					// Preserve backend identifiers for detailed fetches
					id: a.id != null ? a.id : (a.accountId != null ? a.accountId : null),
					// Use accountNumber as the unique selection key
                accountNumber: a.accountNumber || a.number || a.id || ('ACC' + (idx + 1)),
                accountType: a.accountType || a.type || 'Account',
                balance: a.balance != null ? a.balance : (a.currentBalance != null ? a.currentBalance : 0),
                status: a.status || 'Active',
                owner: a.owner || ownerName,
					ifsc: a.ifsc || a.ifscCode || '',
					branch: a.branch || a.branchName || ''
              };
            });
            self.accounts(accounts);
            if (accounts.length > 0) {
              self.selectedAccountId(accounts[0].accountNumber);
            } else {
              self.selectedAccountId(null);
            }
          })
          .catch(function(error) {
            // Optionally log error; keep UI resilient
            // console.error('Failed to load accounts', error);
            self.accounts([]);
            self.selectedAccountId(null);
          });
      };

      // Lifecycle hook: load accounts when view is connected
      self.connected = function() {
        self.fetchAccounts();
      };
    }

    return AccountsViewModel;
});
