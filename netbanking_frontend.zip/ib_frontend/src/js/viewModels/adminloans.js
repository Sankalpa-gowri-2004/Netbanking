/**
 * Loans ViewModel for JET Bank Admin Portal
 */
define(["knockout", "services/authService"], function(ko, authService) {
    function Loan(data) {
        this.loanId = data.loanId;
        this.loanType = data.loanType;
        this.principalAmount = data.principalAmount;
        this.interestRate = data.interestRate;
        this.tenureMonths = data.tenureMonths;
        this.startDate = data.startDate;
        this.remainingAmount = data.remainingAmount;
        this.status = data.status;
        this.borrowerName = data.borrowerName;
        this.borrowerEmail = data.borrowerEmail;
        this.statusClass = "jet-table-status-" + this.status.toLowerCase();
    }

    function LoansViewModel() {
        var self = this;

        var loanTypes = ["Home Loan", "Car Loan", "Personal Loan", "Education Loan", "Gold Loan"];
        var statusOptions = ["ACTIVE", "CLOSED"];
        self.loanTypes = loanTypes;
        self.statusOptions = statusOptions;

        self.filterText = ko.observable("");
        self.filterStatus = ko.observable();
        self.filterType = ko.observable();
        self.isLoading = ko.observable(false);
        self.errorMessage = ko.observable("");
        self.isSaving = ko.observable(false);
        self.saveErrorMessage = ko.observable("");
        self.saveSuccessMessage = ko.observable("");

        // Loans data from API
        self.allLoans = ko.observableArray([]);

        // Load loans from API
        self.loadLoans = function() {
            self.isLoading(true);
            self.errorMessage("");
            
            authService.getAdminLoans()
                .done(function(response) {
                    var loans = response.map(function(loanData) {
                        return new Loan(loanData);
                    });
                    self.allLoans(loans);
                })
                .fail(function(xhr, status, error) {
                    console.error('Error loading loans:', error);
                    self.errorMessage('Failed to load loans. Please try again.');
                })
                .always(function() {
                    self.isLoading(false);
                });
        };

        // Initialize data
        self.loadLoans();

        // Filtering
        self.filteredLoans = ko.computed(function() {
            var filterText = self.filterText().toLowerCase().trim();
            return ko.utils.arrayFilter(self.allLoans(), function(l) {
                var match = true;
                if (filterText) {
                    match = (
                        l.loanType.toLowerCase().indexOf(filterText) > -1 ||
                        l.borrowerName.toLowerCase().indexOf(filterText) > -1 ||
                        l.borrowerEmail.toLowerCase().indexOf(filterText) > -1
                    );
                }
                if (match && self.filterStatus()) {
                    match = l.status === self.filterStatus();
                }
                if (match && self.filterType()) {
                    match = l.loanType === self.filterType();
                }
                return match;
            });
        });

        // Sorting
        self.sortColumn = ko.observable('loanType');
        self.sortAsc = ko.observable(true);
        self.sortBy = function(col) {
            if (self.sortColumn() === col) {
                self.sortAsc(!self.sortAsc());
            } else {
                self.sortColumn(col);
                self.sortAsc(true);
            }
        };

        self.sortedLoans = ko.computed(function() {
            var arr = self.filteredLoans().slice(0);
            var column = self.sortColumn();
            var asc = self.sortAsc();
            arr.sort(function(a, b) {
                var aVal = a[column];
                var bVal = b[column];
                // Numeric sort for amount fields
                if (column === "principalAmount" || column === "remainingAmount" || column === "interestRate" || column === "tenureMonths") {
                    aVal = +aVal;
                    bVal = +bVal;
                    return asc ? aVal - bVal : bVal - aVal;
                }
                return asc
                    ? aVal.toString().localeCompare(bVal.toString())
                    : bVal.toString().localeCompare(aVal.toString());
            });
            return arr;
        });

        // Paging
        self.pageSize = ko.observable(5);
        self.pageIndex = ko.observable(0);
        self.totalPages = ko.computed(function() {
            return Math.ceil(self.sortedLoans().length / self.pageSize());
        });
        self.pagedLoans = ko.computed(function() {
            var start = self.pageIndex() * self.pageSize();
            return self.sortedLoans().slice(start, start + self.pageSize());
        });
        self.nextPage = function() {
            if (self.pageIndex() < self.totalPages() - 1) self.pageIndex(self.pageIndex() + 1);
        };
        self.prevPage = function() {
            if (self.pageIndex() > 0) self.pageIndex(self.pageIndex() - 1);
        };

        // Reset pageIndex on filter/sort change
        self.filterText.subscribe(function() { self.pageIndex(0); });
        self.filterStatus.subscribe(function() { self.pageIndex(0); });
        self.filterType.subscribe(function() { self.pageIndex(0); });
        self.sortColumn.subscribe(function() { self.pageIndex(0); });
        self.sortAsc.subscribe(function() { self.pageIndex(0); });

        // Dialog/modal logic
        self.showLoanDialog = ko.observable(false);
        self.isEditMode = ko.observable(false);
        self.dialogLoan = ko.observable({
            id: "",
            loanType: "",
            principalAmount: 0,
            interestRate: 0,
            tenureMonths: 0,
            startDate: "",
            remainingAmount: 0,
            status: "",
            borrowerName: "",
            borrowerEmail: ""
        });

        self.openEditLoan = function(loan) {
            self.isEditMode(true);
            self.dialogLoan({
                id: loan.loanId, // Use the actual loan ID from the API
                loanType: loan.loanType,
                principalAmount: loan.principalAmount,
                interestRate: loan.interestRate,
                tenureMonths: loan.tenureMonths,
                startDate: loan.startDate,
                remainingAmount: loan.remainingAmount,
                status: loan.status,
                borrowerName: loan.borrowerName,
                borrowerEmail: loan.borrowerEmail
            });
            self.showLoanDialog(true);
        };

        self.saveLoan = function() {
            var loan = self.dialogLoan();
            if (!loan.principalAmount || !loan.interestRate || !loan.tenureMonths) {
                alert("Principal Amount, Interest Rate, and Tenure are required.");
                return;
            }
            
            // Update existing loan via API
            self.isSaving(true);
            self.saveErrorMessage("");
            
            // Prepare data for API
            var updateData = {
                status: loan.status,
                principalAmount: loan.principalAmount,
                interestRate: loan.interestRate,
                tenureMonths: loan.tenureMonths,
                startDate: loan.startDate,
                remainingAmount: loan.remainingAmount
            };
            
            authService.updateLoan(loan.id, updateData)
                .done(function(response) {
                    // Update the loan in the local array using loan ID
                    var idx = self.allLoans().findIndex(function(l) { 
                        return l.loanId === loan.id; 
                    });
                    if (idx > -1) {
                        // Update the loan object with new data
                        var updatedLoan = self.allLoans()[idx];
                        updatedLoan.principalAmount = loan.principalAmount;
                        updatedLoan.interestRate = loan.interestRate;
                        updatedLoan.tenureMonths = loan.tenureMonths;
                        updatedLoan.startDate = loan.startDate;
                        updatedLoan.remainingAmount = loan.remainingAmount;
                        updatedLoan.status = loan.status;
                        updatedLoan.statusClass = "jet-table-status-" + loan.status.toLowerCase();
                        self.allLoans.valueHasMutated();
                    }
                    self.saveSuccessMessage('Loan updated successfully!');
                    self.closeDialog();
                    // Clear success message after 3 seconds
                    setTimeout(function() {
                        self.saveSuccessMessage("");
                    }, 3000);
                })
                .fail(function(xhr, status, error) {
                    console.error('Error updating loan:', error);
                    self.saveErrorMessage('Failed to update loan. Please try again.');
                })
                .always(function() {
                    self.isSaving(false);
                });
        };

        self.closeDialog = function() {
            self.showLoanDialog(false);
        };

        // Loan status actions
        self.activateLoan = function(loan) {
            if (loan.status !== "CLOSED") return;
            if (confirm("Activate loan: " + loan.loanType + " for " + loan.borrowerName + "?")) {
                loan.status = "ACTIVE";
                loan.statusClass = "jet-table-status-active";
                self.allLoans.valueHasMutated();
                self.updateCharts();
            }
        };
        self.closeLoan = function(loan) {
            if (loan.status !== "ACTIVE") return;
            if (confirm("Close loan: " + loan.loanType + " for " + loan.borrowerName + "?")) {
                loan.status = "CLOSED";
                loan.statusClass = "jet-table-status-closed";
                self.allLoans.valueHasMutated();
                self.updateCharts();
            }
        };

        // Chart: status distribution
        self.loanStatusDist = ko.observableArray([]);
        // Chart: loan type distribution
        self.loanTypeDist = ko.observableArray([]);

        self.updateCharts = function() {
            // Update status distribution
            var aggStatus = {};
            var aggType = {};
            var typeTotal = 0;

            self.allLoans().forEach(function(l) {
                var s = l.status;
                aggStatus[s] = (aggStatus[s] || 0) + 1;
                var t = l.loanType;
                aggType[t] = (aggType[t] || 0) + 1;
                typeTotal++;
            });

            var chartStatus = [];
            if (aggStatus["ACTIVE"]) chartStatus.push({ name: "Active", value: aggStatus["ACTIVE"], group: "Active", color: "#28a745" });
            if (aggStatus["CLOSED"]) chartStatus.push({ name: "Closed", value: aggStatus["CLOSED"], group: "Closed", color: "#7b8998" });
            self.loanStatusDist(chartStatus);

            // Loan type bar: percent of total
            var percents = [];
            for (var t in aggType) {
                var pct = Math.round((aggType[t] / typeTotal) * 100);
                var color = "#1864ab";
                if (t === "Home Loan") color = "linear-gradient(90deg,#1864ab,#ffd700)";
                if (t === "Car Loan") color = "#28a745";
                if (t === "Personal Loan") color = "#17a2b8";
                if (t === "Education Loan") color = "#dc3545";
                if (t === "Gold Loan") color = "#ff8700";
                percents.push({ loanType: t, value: pct, color: color });
            }
            self.loanTypeDist(percents);
        };

        self.allLoans.subscribe(self.updateCharts);
        self.updateCharts();
    }
    return new LoansViewModel();
});
