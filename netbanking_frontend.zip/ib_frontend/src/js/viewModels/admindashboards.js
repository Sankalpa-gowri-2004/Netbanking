/**
 * Dashboard ViewModel for JET Bank Admin Portal
 */
define(['knockout', 'services/authService', 'ojs/ojbutton', 'ojs/ojknockout'], function(ko, authService) {
    function DashboardViewModel() {
        let self = this;

        // Observable properties
        self.isLoading = ko.observable(true);
        self.error = ko.observable(null);
        self.dashboardStats = ko.observable({
            totalAccounts: 0,
            totalLoans: 0,
            pendingApprovals: 0,
            totalBranches: 0,
            loansPerBranch: []
        });

        // Chart colors for branches
        const branchColors = [
            '#28a745', '#17a2b8', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14'
        ];

        // Load dashboard data
        self.loadDashboardData = function() {
            self.isLoading(true);
            self.error(null);
            
            authService.getAdminDashboard()
                .done(function(response) {
                    // Transform the API response to match our UI structure
                    const transformedData = {
                        totalAccounts: response.totalAccounts,
                        totalLoans: response.totalLoans,
                        pendingApprovals: response.pendingApprovals,
                        totalBranches: response.totalBranches,
                        loansPerBranch: Object.entries(response.loansPerBranch).map(([branch, percentage], index) => ({
                            branch: branch,
                            value: Math.round(percentage * 100) / 100, // Round to 2 decimal places
                            color: branchColors[index % branchColors.length]
                        }))
                    };
                    
                    self.dashboardStats(transformedData);
                    self.isLoading(false);
                })
                .fail(function(xhr, status, error) {
                    console.error('Failed to load dashboard data:', error);
                    self.error('Failed to load dashboard data. Please try again.');
                    self.isLoading(false);
                });
        };

        // Refresh data method
        self.refreshData = function() {
            self.loadDashboardData();
        };

        // Lifecycle hook: load dashboard data when view is connected
        self.connected = function() {
            self.loadDashboardData();
        };
    }
    return new DashboardViewModel();
});
