
define(['knockout', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojformlayout'],
  function (ko) {

    function LoanRepaymentViewModel() {
      var self = this;

      // User info
      self.userName = ko.observable(localStorage.getItem('firstName') || 'User');

      // Inputs for making repayment
      self.loanId = ko.observable('');
      self.repaymentAmount = ko.observable('');

      // Inputs for fetching repayment details
      self.fetchLoanId = ko.observable('');

      // Repayment response messages
      self.message = ko.observable('');
      self.repaymentDetails = ko.observable(null);

      // Mock repayment API
      self.makeRepayment = function () {
        const loanId = self.loanId();
        const amount = parseFloat(self.repaymentAmount());

        if (!loanId || isNaN(amount) || amount <= 0) {
          self.message('⚠️ Please enter valid Loan ID and Amount.');
          return;
        }

        // Simulate API call
        setTimeout(() => {
          self.message(`✅ Repayment of ₹${amount} for Loan ID ${loanId} was successful.`);
          // Clear inputs
          self.loanId('');
          self.repaymentAmount('');
        }, 500);
      };

      // Mock fetch repayment details API
      self.getRepaymentDetails = function () {
        const loanId = self.fetchLoanId();
        if (!loanId) {
          self.message('⚠️ Please enter a Loan ID to fetch details.');
          return;
        }

        // Simulate data fetch
        setTimeout(() => {
          const dummyData = {
            loanId: loanId,
            totalPaid: 25000,
            remainingBalance: 75000,
            lastPaymentDate: '2025-10-10'
          };
          self.repaymentDetails(dummyData);
          self.message('');
        }, 500);
      };
    }

    return LoanRepaymentViewModel;
});
