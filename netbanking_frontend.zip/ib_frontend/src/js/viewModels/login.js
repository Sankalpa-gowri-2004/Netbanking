define([
  'knockout',
  'ojs/ojrouter',
  'services/authService',
  'ojs/ojinputtext',
  'oj-c/input-password',
  'ojs/ojbutton'
], function (ko, Router, authService) {
  function LoginViewModel() {
    const self = this;

    self.email = ko.observable('');
    self.password = ko.observable('');
    self.message = ko.observable('');

    self.login = function () {
      authService
        .loginFirstFactor(self.email(), self.password())
        .then((response) => {
          if (response.success) {
            localStorage.setItem('email', self.email());
            window.appRouter && window.appRouter.go({ path: 'otp' });
          } else {
            self.message('Invalid credentials');
          }
        })
        .catch((err) => self.message('Error: ' + err.responseText));
    };

    self.goSignup = function () {
      window.appRouter && window.appRouter.go({ path: 'signup' });
    };
  }

  return new LoginViewModel();
});
