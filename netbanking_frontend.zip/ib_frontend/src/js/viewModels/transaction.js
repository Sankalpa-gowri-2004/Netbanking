define(['knockout', 'services/authService'], function(ko, authService) {
  function TransactionViewModel(params) {
    var self = this;

    // User info
    self.userName = ko.observable(JSON.parse(localStorage.getItem('user')).name || 'User');

    // Form fields
    self.fromAccountId = ko.observable('');
    self.toAccountId = ko.observable('');
    self.amount = ko.observable('');
    self.description = ko.observable('');

    // State management
    self.isSubmitting = ko.observable(false);
    self.message = ko.observable('');

    // Validation errors
    self.fromAccountError = ko.observable('');
    self.toAccountError = ko.observable('');
    self.amountError = ko.observable('');
    self.descriptionError = ko.observable('');

    // Validation functions
    self.validateFromAccount = function() {
      var value = self.fromAccountId();
      if (!value) {
        self.fromAccountError('From account is required');
        return false;
      }
      if (isNaN(value) || value <= 0) {
        self.fromAccountError('Please enter a valid account number');
        return false;
      }
      self.fromAccountError('');
      return true;
    };

    self.validateToAccount = function() {
      var value = self.toAccountId();
      if (!value) {
        self.toAccountError('To account is required');
        return false;
      }
      if (isNaN(value) || value <= 0) {
        self.toAccountError('Please enter a valid account number');
        return false;
      }
      if (value === self.fromAccountId()) {
        self.toAccountError('Cannot transfer to the same account');
        return false;
      }
      self.toAccountError('');
      return true;
    };

    self.validateAmount = function() {
      var value = parseFloat(self.amount());
      if (!self.amount()) {
        self.amountError('Amount is required');
        return false;
      }
      if (isNaN(value) || value <= 0) {
        self.amountError('Please enter a valid amount');
        return false;
      }
      if (value < 1) {
        self.amountError('Minimum transfer amount is ₹1');
        return false;
      }
      self.amountError('');
      return true;
    };

    self.validateDescription = function() {
      var value = self.description();
      if (value && value.length > 100) {
        self.descriptionError('Description must be less than 100 characters');
        return false;
      }
      self.descriptionError('');
      return true;
    };

    // Overall validation
    self.canSubmit = ko.computed(function() {
      return self.validateFromAccount() && 
             self.validateToAccount() && 
             self.validateAmount() && 
             self.validateDescription() &&
             !self.isSubmitting();
    });

    // Real-time validation on input change
    self.fromAccountId.subscribe(function() {
      self.validateFromAccount();
    });

    self.toAccountId.subscribe(function() {
      self.validateToAccount();
    });

    self.amount.subscribe(function() {
      self.validateAmount();
    });

    self.description.subscribe(function() {
      self.validateDescription();
    });

    // Submit transfer
    self.submitTransfer = function() {
      // Clear previous messages
      self.message('');

      // Validate all fields
      var isValid = self.validateFromAccount() && 
                   self.validateToAccount() && 
                   self.validateAmount() && 
                   self.validateDescription();

      if (!isValid) {
        self.message('Please fix the errors above before submitting.');
        return false;
      }

      self.isSubmitting(true);

      // Prepare transfer data
      var transferData = {
        fromAccountId: parseInt(self.fromAccountId()),
        toAccountId: parseInt(self.toAccountId()),
        amount: parseFloat(self.amount()),
        description: self.description() || 'Money transfer'
      };

      console.log('Submitting transfer data:', transferData);

      // Call API
      authService.transferMoney(transferData)
        .then(function(response) {
          console.log('Transfer successful:', response);
          self.message('Transfer completed successfully!');
          
          // Reset form after successful transfer
          setTimeout(function() {
            self.resetForm();
          }, 3000);
        })
        .catch(function(error) {
          console.error('Transfer failed:', error);
          var errorMessage = 'Transfer failed. Please try again.';
          
          if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
          } else if (error.status === 400) {
            errorMessage = 'Invalid transfer details. Please check your inputs.';
          } else if (error.status === 401) {
            errorMessage = 'Authentication failed. Please login again.';
          } else if (error.status === 403) {
            errorMessage = 'Insufficient funds or account access denied.';
          } else if (error.status === 404) {
            errorMessage = 'Account not found. Please verify account numbers.';
          }
          
          self.message(errorMessage);
        })
        .always(function() {
          self.isSubmitting(false);
        });

      return false; // Prevent form submission
    };

    // Reset form
    self.resetForm = function() {
      self.fromAccountId('');
      self.toAccountId('');
      self.amount('');
      self.description('');
      self.message('');
      self.fromAccountError('');
      self.toAccountError('');
      self.amountError('');
      self.descriptionError('');
    };

    // Initialize with sample data for testing
    self.connected = function() {
      // You can pre-fill with sample data for testing
      // self.fromAccountId('175770212499');
      // self.toAccountId('175770229196');
      // self.amount('150.75');
      // self.description('Payment for groceries');
    };
  }

  return TransactionViewModel;
});