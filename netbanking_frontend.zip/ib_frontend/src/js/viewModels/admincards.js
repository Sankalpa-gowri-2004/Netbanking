/**
 * Cards ViewModel for JET Bank Admin Portal
 */
define(['knockout', 'services/authService'], function(ko, authService) {
    function Card(data) {
        this.cardNumber = data.cardNumber;
        this.cardType = data.cardType;
        this.expiryDate = data.expiryDate;
        this.status = data.status;
        this.cardHolderName = data.cardHolderName;
        this.accountNumber = data.accountNumber;
        this.statusClass = "jet-table-status-" + (data.status === "ACTIVE" ? "unblocked" : "blocked");
    }

    function CardsViewModel() {
        var self = this;

        var cardTypes = ["DEBIT", "CREDIT"];
        var statusOptions = ["ACTIVE", "BLOCKED"];

        self.cardTypes = cardTypes;
        self.statusOptions = statusOptions;

        self.filterText = ko.observable("");
        self.filterType = ko.observable();
        self.filterStatus = ko.observable();
        self.isLoading = ko.observable(false);
        self.errorMessage = ko.observable("");
        self.isUpdating = ko.observable(false);
        self.updateErrorMessage = ko.observable("");
        self.updateSuccessMessage = ko.observable("");

        // Cards data from API
        self.allCards = ko.observableArray([]);

        // Load cards from API
        self.loadCards = function() {
            self.isLoading(true);
            self.errorMessage("");
            
            authService.getAdminCards()
                .done(function(response) {
                    var cards = response.map(function(cardData) {
                        return new Card(cardData);
                    });
                    self.allCards(cards);
                })
                .fail(function(xhr, status, error) {
                    console.error('Error loading cards:', error);
                    self.errorMessage('Failed to load cards. Please try again.');
                })
                .always(function() {
                    self.isLoading(false);
                });
        };

        // Initialize data
        self.loadCards();

        // Filtering
        self.filteredCards = ko.computed(function() {
            var filterText = self.filterText().toLowerCase().trim();
            return ko.utils.arrayFilter(self.allCards(), function(c) {
                var match = true;
                if (filterText) {
                    match = (
                        c.cardNumber.toLowerCase().indexOf(filterText) > -1 ||
                        c.cardHolderName.toLowerCase().indexOf(filterText) > -1 ||
                        c.accountNumber.toLowerCase().indexOf(filterText) > -1
                    );
                }
                if (match && self.filterType()) {
                    match = c.cardType === self.filterType();
                }
                if (match && self.filterStatus()) {
                    match = c.status === self.filterStatus();
                }
                return match;
            });
        });

        // Sorting
        self.sortColumn = ko.observable('cardNumber');
        self.sortAsc = ko.observable(true);
        self.sortBy = function(col) {
            if (self.sortColumn() === col) {
                self.sortAsc(!self.sortAsc());
            } else {
                self.sortColumn(col);
                self.sortAsc(true);
            }
        };
        self.sortedCards = ko.computed(function() {
            var arr = self.filteredCards().slice(0);
            var column = self.sortColumn();
            var asc = self.sortAsc();
            arr.sort(function(a, b) {
                var aVal = a[column];
                var bVal = b[column];
                return asc
                    ? aVal.toString().localeCompare(bVal.toString())
                    : bVal.toString().localeCompare(aVal.toString());
            });
            return arr;
        });

        // Paging
        self.pageSize = ko.observable(5);
        self.pageIndex = ko.observable(0);
        self.totalPages = ko.computed(function() {
            return Math.ceil(self.sortedCards().length / self.pageSize());
        });
        self.pagedCards = ko.computed(function() {
            var start = self.pageIndex() * self.pageSize();
            return self.sortedCards().slice(start, start + self.pageSize());
        });
        self.nextPage = function() {
            if (self.pageIndex() < self.totalPages() - 1) self.pageIndex(self.pageIndex() + 1);
        };
        self.prevPage = function() {
            if (self.pageIndex() > 0) self.pageIndex(self.pageIndex() - 1);
        };

        // Reset pageIndex on filter/sort change
        self.filterText.subscribe(function() { self.pageIndex(0); });
        self.filterType.subscribe(function() { self.pageIndex(0); });
        self.filterStatus.subscribe(function() { self.pageIndex(0); });
        self.sortColumn.subscribe(function() { self.pageIndex(0); });
        self.sortAsc.subscribe(function() { self.pageIndex(0); });

        // Row Actions
        self.blockCard = function(card) {
            if (card.status !== "ACTIVE") return;
            if (confirm("Block card: " + card.cardNumber + "?")) {
                self.isUpdating(true);
                self.updateErrorMessage("");
                
                // Prepare data for API
                var updateData = {
                    cardType: card.cardType,
                    expiryDate: card.expiryDate,
                    status: "BLOCKED",
                    username: card.cardHolderName,
                    accountNumber: card.accountNumber
                };
                
                authService.updateCard(card.cardNumber, updateData)
                    .done(function(response) {
                        // Update the card in the local array
                        card.status = "BLOCKED";
                        card.statusClass = "jet-table-status-blocked";
                        self.allCards.valueHasMutated();
                        self.updateSuccessMessage('Card blocked successfully!');
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.updateSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error blocking card:', error);
                        self.updateErrorMessage('Failed to block card. Please try again.');
                    })
                    .always(function() {
                        self.isUpdating(false);
                    });
            }
        };
        self.unblockCard = function(card) {
            if (card.status !== "BLOCKED") return;
            if (confirm("Unblock card: " + card.cardNumber + "?")) {
                self.isUpdating(true);
                self.updateErrorMessage("");
                
                // Prepare data for API
                var updateData = {
                    cardType: card.cardType,
                    expiryDate: card.expiryDate,
                    status: "ACTIVE",
                    username: card.cardHolderName,
                    accountNumber: card.accountNumber
                };
                
                authService.updateCard(card.cardNumber, updateData)
                    .done(function(response) {
                        // Update the card in the local array
                        card.status = "ACTIVE";
                        card.statusClass = "jet-table-status-unblocked";
                        self.allCards.valueHasMutated();
                        self.updateSuccessMessage('Card unblocked successfully!');
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.updateSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error unblocking card:', error);
                        self.updateErrorMessage('Failed to unblock card. Please try again.');
                    })
                    .always(function() {
                        self.isUpdating(false);
                    });
            }
        };
    }
    return new CardsViewModel();
});
