define([
  'knockout',
  'services/authService',
  'ojs/ojarraydataprovider',
  'ojs/ojselectsingle',
  'ojs/ojinputnumber',
  'ojs/ojbutton',
  'ojs/ojformlayout'
], function (ko, authService, ArrayDataProvider) {
  function CreateAccountViewModel() {
    const self = this;
    
    // Form fields
    self.accountType = ko.observable('');
    self.ifscCode = ko.observable('');
    self.message = ko.observable('');
    self.isLoading = ko.observable(false);
    
    // Account types
    self.accountTypes = [
      { value: 'SAVINGS', label: 'Savings Account' },
      { value: 'CHECKING', label: 'Checking Account' },
      { value: 'BUSINESS', label: 'Business Account' }
    ];
    self.accountTypesDP = new ArrayDataProvider(self.accountTypes, { keyAttributes: 'value' });
    
    // Create account method
    self.createAccount = function() {
      const hasAccountType = !!self.accountType();
      const hasIfsc = !!self.ifscCode();
      if (!hasAccountType || !hasIfsc) {
        self.message('Please fill in all fields');
        return;
      }
      
      self.isLoading(true);
      self.message('');
      
      const userStr = localStorage.getItem('user');
      let userId = null;
      try {
        const userObj = userStr ? JSON.parse(userStr) : null;
        userId = userObj && userObj.id != null ? userObj.id : null;
      } catch (e) {
        userId = null;
      }
      
      const accountData = {
        userId: userId,
        accountType: self.accountType(),
        currency: 'INR',
        ifscCode: self.ifscCode()
      };
      
      authService.createAccount(accountData)
        .then(function(response) {
          // Best-effort success detection
          if (response && (response.success === true || response.accountNumber || response.id)) {
            const accNum = response.accountNumber || response.id || '';
            self.message('Account created successfully! ' + (accNum ? ('Account Number: ' + accNum) : ''));
            // Clear form
            self.accountType('');
            self.ifscCode('');
          } else {
            const msg = (response && response.message) ? response.message : 'Unknown error';
            self.message('Failed to create account: ' + msg);
          }
        })
        .catch(function(error) {
          self.message('Error: ' + (error && error.message ? error.message : 'Request failed'));
        })
        .always(function() {
          self.isLoading(false);
        });
    };
    
    // Back to accounts
    self.goBack = function() {
      if (window.appRouter) {
        window.appRouter.go({ path: 'accounts' });
      }
    };
  }
  
  return CreateAccountViewModel;
});


