/**
 * Accounts ViewModel for JET Bank Admin Portal
 */
define(["knockout", "services/authService"], function(ko, authService) {
    function Account(data) {
        this.accountNo = data.accountNumber;
        this.holderName = data.holderName;
        this.type = data.type;
        this.branch = data.branch;
        this.status = data.status;
        this.balance = data.balance;
        this.statusClass = "jet-table-status-" + this.status.toLowerCase().replace(/\s/g, "");
    }

    function AccountsViewModel() {
        var self = this;

        // Account types and status options
        var accountTypes = ["SAVINGS", "CURRENT", "SALARY", "NRI"];
        var branches = ["Universal Home Branch", "Oracle North Branch", "Oracle Main Branch", "Oracle South Branch"];
        var statusOptions = ["ACTIVE", "FROZEN", "CLOSED"];

        self.accountTypes = accountTypes;
        self.branches = branches;
        self.statusOptions = statusOptions;

        // Filter observables
        self.filterText = ko.observable("");
        self.filterType = ko.observable();
        self.filterBranch = ko.observable();
        self.filterStatus = ko.observable();

        // Loading state
        self.isLoading = ko.observable(false);
        self.errorMessage = ko.observable("");
        self.isSaving = ko.observable(false);
        self.saveErrorMessage = ko.observable("");
        self.saveSuccessMessage = ko.observable("");

        // Accounts data
        self.allAccounts = ko.observableArray([]);

        // API call function
        self.fetchAccounts = function() {
            self.isLoading(true);
            self.errorMessage("");
            
            // Build filters object
            var filters = {};
            if (self.filterType()) {
                filters.type = self.filterType();
            }
            if (self.filterBranch()) {
                filters.branch = self.filterBranch();
            }
            if (self.filterStatus()) {
                filters.status = self.filterStatus();
            }
            if (self.filterText()) {
                filters.holderName = self.filterText();
            }

            // Use authService to fetch accounts
            authService.getAdminAccounts(filters)
                .done(function(data) {
                    // Convert API response to Account objects
                    var accounts = data.map(function(accountData) {
                        return new Account(accountData);
                    });
                    self.allAccounts(accounts);
                    self.pageIndex(0); // Reset to first page
                })
                .fail(function(xhr, status, error) {
                    console.error('Error fetching accounts:', error);
                    self.errorMessage('Failed to load accounts. Please try again.');
                    self.allAccounts([]);
                })
                .always(function() {
                    self.isLoading(false);
                });
        };

        // Filtering support - now just uses the API data directly
        self.filteredAccounts = ko.computed(function() {
            return self.allAccounts();
        });

        // Sorting
        self.sortColumn = ko.observable('accountNo');
        self.sortAsc = ko.observable(true);
        self.sortBy = function(col) {
            if (self.sortColumn() === col) {
                self.sortAsc(!self.sortAsc());
            } else {
                self.sortColumn(col);
                self.sortAsc(true);
            }
        };

        self.sortedAccounts = ko.computed(function() {
            var arr = self.filteredAccounts().slice(0);
            var column = self.sortColumn();
            var asc = self.sortAsc();
            arr.sort(function(a, b) {
                var aVal = a[column];
                var bVal = b[column];
                // Numeric sort for balance, default lex for others
                if (column === "balance") {
                    aVal = +aVal;
                    bVal = +bVal;
                    return asc ? aVal - bVal : bVal - aVal;
                }
                return asc
                    ? aVal.toString().localeCompare(bVal.toString())
                    : bVal.toString().localeCompare(aVal.toString());
            });
            return arr;
        });

        // Paging
        self.pageSize = ko.observable(5);
        self.pageIndex = ko.observable(0);

        self.totalPages = ko.computed(function() {
            return Math.ceil(self.sortedAccounts().length / self.pageSize());
        });

        self.pagedAccounts = ko.computed(function() {
            var start = self.pageIndex() * self.pageSize();
            return self.sortedAccounts().slice(start, start + self.pageSize());
        });

        self.nextPage = function() {
            if (self.pageIndex() < self.totalPages() - 1) self.pageIndex(self.pageIndex() + 1);
        };
        self.prevPage = function() {
            if (self.pageIndex() > 0) self.pageIndex(self.pageIndex() - 1);
        };

        // Trigger API call when filters change
        self.filterText.subscribe(function() { 
            self.pageIndex(0);
            self.fetchAccounts();
        });
        self.filterType.subscribe(function() { 
            self.pageIndex(0);
            self.fetchAccounts();
        });
        self.filterBranch.subscribe(function() { 
            self.pageIndex(0);
            self.fetchAccounts();
        });
        self.filterStatus.subscribe(function() { 
            self.pageIndex(0);
            self.fetchAccounts();
        });
        self.sortColumn.subscribe(function() { self.pageIndex(0); });
        self.sortAsc.subscribe(function() { self.pageIndex(0); });

        // Dialog/modal logic
        self.showAccountDialog = ko.observable(false);
        self.showViewDialog = ko.observable(false);
        self.isEditMode = ko.observable(false);

        self.dialogAccount = ko.observable({
            accountNumber: "",
            username: "",
            holderName: "",
            accountType: "",
            branchName: "",
            status: "",
            balance: 0,
            statusClass: ""
        });

        self.openAddAccount = function() {
            self.isEditMode(false);
            self.dialogAccount({
                accountNumber: "",
                username: "",
                holderName: "",
                accountType: accountTypes[0],
                branchName: branches[0],
                status: "ACTIVE",
                balance: 0,
                statusClass: "jet-table-status-active"
            });
            self.showAccountDialog(true);
        };

        self.editAccount = function(account) {
            self.isEditMode(true);
            self.dialogAccount({
                accountNumber: account.accountNo,
                username: account.holderName, // Using holderName as username for edit mode
                holderName: account.username,
                accountType: account.type,
                branchName: account.branch,
                status: account.status,
                balance: account.balance,
                statusClass: account.statusClass
            });
            self.showAccountDialog(true);
        };

        self.saveAccount = function() {
            var acct = self.dialogAccount();
            if (!acct.accountNumber || !acct.username || !acct.holderName) {
                alert("Account Number, Username, and Holder Name are required.");
                return;
            }
            
            if (self.isEditMode()) {
                // Update existing account via API
                self.isSaving(true);
                self.saveErrorMessage("");
                
                // Prepare data for API
                var updateData = {
                    branchName: acct.branchName,
                    username: acct.username,
                    accountType: acct.accountType,
                    balance: acct.balance,
                    status: acct.status,
                    accountNumber: acct.accountNumber
                };
                
                authService.updateAccount(acct.accountNumber, updateData)
                    .done(function(response) {
                        // Update the account in the local array
                        var idx = self.allAccounts().findIndex(function(a) { return a.accountNo === acct.accountNumber; });
                        if (idx > -1) {
                            self.allAccounts.splice(idx, 1, new Account(acct));
                        }
                        self.saveSuccessMessage('Account updated successfully!');
                        self.closeDialog();
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.saveSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error updating account:', error);
                        self.saveErrorMessage('Failed to update account. Please try again.');
                    })
                    .always(function() {
                        self.isSaving(false);
                    });
            } else {
                // Create new customer via API
                self.isSaving(true);
                self.saveErrorMessage("");
                
                // Prepare data for API
                var createData = {
                    branchName: acct.branchName,
                    username: acct.username,
                    accountType: acct.accountType,
                    balance: acct.balance.toString(),
                    status: acct.status,
                    accountNumber: acct.accountNumber
                };
                
                authService.createCustomer(createData)
                    .done(function(response) {
                        // Add the new account to the local array
                        self.allAccounts.unshift(new Account(acct));
                        self.saveSuccessMessage('Customer created successfully!');
                        self.closeDialog();
                        // Clear success message after 3 seconds
                        setTimeout(function() {
                            self.saveSuccessMessage("");
                        }, 3000);
                    })
                    .fail(function(xhr, status, error) {
                        console.error('Error creating customer:', error);
                        self.saveErrorMessage('Failed to create customer. Please try again.');
                    })
                    .always(function() {
                        self.isSaving(false);
                    });
            }
        };

        self.closeDialog = function() {
            self.showAccountDialog(false);
            self.showViewDialog(false);
        };

        self.viewAccount = function(account) {
            self.dialogAccount({
                accountNo: account.accountNo,
                holderName: account.holderName,
                type: account.type,
                branch: account.branch,
                status: account.status,
                balance: account.balance,
                statusClass: account.statusClass
            });
            self.showViewDialog(true);
        };

        self.freezeAccount = function(account) {
            if (account.status !== "ACTIVE") return;
            if (confirm("Freeze account: " + account.accountNo + "?")) {
                account.status = "FROZEN";
                account.statusClass = "jet-table-status-frozen";
                self.allAccounts.valueHasMutated();
            }
        };

        // Initialize data on page load
        self.initialize = function() {
            self.fetchAccounts();
        };

        // Call initialize when the view model is created
        self.initialize();
    }
    return new AccountsViewModel();
});
