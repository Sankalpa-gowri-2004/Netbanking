define(['knockout', 'services/authService', 'ojs/ojarraydataprovider', 'ojs/ojtable', 'ojs/ojlistview', 'ojs/ojavatar', 'ojs/ojknockout'], function(ko, authService, ArrayDataProvider) {
  function BranchesViewModel() {
    const self = this;

    self.branches = ko.observableArray([]);

    self.branchesDP = new ArrayDataProvider(self.branches, { keyAttributes: 'id' });

    self.isLoading = ko.observable(false);
    self.error = ko.observable('');

    self.fetchBranches = function() {
      self.isLoading(true);
      self.error('');
      authService.getBranches()
        .then(function(response) {
          var mapped = (response || []).map(function(b, idx){
            return {
              id: b.id != null ? b.id : (idx + 1),
              name: b.branchName || '',
              city: b.city || '',
              ifsc: b.ifscCode || '',
              address: b.address || '',
              phone: b.contactNumber || ''
            };
          });
          self.branches(mapped);
          self.isLoading(false);
          
        })
        .catch(function(err){
          self.error((err && err.message) ? err.message : 'Failed to load branches');
          self.branches([]);
        })
        .always(function(){
          self.isLoading(false);
        });
    };

    self.connected = function() {
      self.fetchBranches();
    };
  }

  return BranchesViewModel;
});


