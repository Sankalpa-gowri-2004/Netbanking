define([
  'knockout',
  'ojs/ojrouter',
  'services/authService',
  'ojs/ojinputtext',
  'oj-c/input-password',
  'ojs/ojbutton'
], function (ko, Router, authService) {
  function SignupViewModel() {
    const self = this;

    self.username = ko.observable('');
    self.email = ko.observable('');
    self.password = ko.observable('');
    self.message = ko.observable('');

    self.signup = function () {
      authService
        .signup(self.username(), self.email(), self.password())
        .then((response) => {
          if (response.success) {
            self.message(response.message);
            setTimeout(() => { window.appRouter && window.appRouter.go({ path: 'login' }); }, 2000);
          } else {
            self.message('Signup failed');
          }
        })
        .catch((err) => self.message('Error: ' + err.responseText));
    };
  }

  return new SignupViewModel();
});
