package com.oracle.internetBanking.exception;

public class InvalidCredentialsException extends  RuntimeException{
    public InvalidCredentialsException(String message) {
        super(message);
    }
}