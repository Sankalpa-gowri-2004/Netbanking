package com.oracle.internetBanking.dto.request;

import lombok.Data;

@Data
public class OtpRequestDto {
    private String email;
}
