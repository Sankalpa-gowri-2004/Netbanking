package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.LoanStatus;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanResponseDto {
    private Long id;
    private LoanStatus status;
    private String loanType;
    private BigDecimal principalAmount;
    private BigDecimal interestRate;
    private Integer tenureMonths;
    private Date startDate;
    private Long userId;
    private  BigDecimal remainingAmount;
}
