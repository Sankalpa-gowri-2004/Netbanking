package com.oracle.internetBanking.enums;

public enum PaymentStatus {
    ACTIVE, CANCELLED
}