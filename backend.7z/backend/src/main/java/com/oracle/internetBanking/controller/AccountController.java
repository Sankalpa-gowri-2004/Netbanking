package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.request.AccountRequestDto;
import com.oracle.internetBanking.dto.request.TransactionFilterCriteria;
import com.oracle.internetBanking.dto.response.AccountResponseDto;
import com.oracle.internetBanking.dto.response.AccountSummaryDto;
import com.oracle.internetBanking.dto.response.DetailedUserDto;
import com.oracle.internetBanking.dto.response.MiniStatementDto;
import com.oracle.internetBanking.service.AccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@Slf4j
public class AccountController {

    private final AccountService accountService;

    @PostMapping
    public ResponseEntity<AccountResponseDto> createAccount(@RequestBody AccountRequestDto dto) {
        AccountResponseDto account = accountService.createAccount(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(account);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<AccountSummaryDto>> getAccountsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(accountService.getAccountsByUserId(userId));
    }

    @GetMapping("/{accountId}/mini-statement")
    public ResponseEntity<List<MiniStatementDto>> getMiniStatement(@PathVariable Long accountId) {
        return ResponseEntity.ok(accountService.getMiniStatement(accountId));
    }

//    @GetMapping("/{userId}/detailed")
//    public  ResponseEntity<List<DetailedUserDto>> getDetailedInfo(@PathVariable Long userId){
//        log.info("User with:{}",userId);
//        return ResponseEntity.ok(accountService.getDetailedInfo(userId));
//    }

    @GetMapping("/{accountId}/detailed")
    public  ResponseEntity<DetailedUserDto> getDetailedInfo(@PathVariable Long accountId){
        log.info("Account with:{}",accountId);
        return ResponseEntity.ok(accountService.getDetailedInfo(accountId));
    }

    @GetMapping("/{accountId}/statement")
    public ResponseEntity<List<MiniStatementDto>> getFilteredTransactions(
            @PathVariable Long accountId,
            @RequestBody TransactionFilterCriteria criteria) {
        return ResponseEntity.ok(accountService.getFilteredTransactions(accountId, criteria));
    }

}
