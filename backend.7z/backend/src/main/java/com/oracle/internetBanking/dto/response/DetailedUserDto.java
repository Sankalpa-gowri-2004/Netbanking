package com.oracle.internetBanking.dto.response;

/**
 * @author mirzbeg
 **/

import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DetailedUserDto {

    // --- Account Details ---
    private String accountNumber;
    private AccountType accountType;
    private BigDecimal balance;
    private String currency;
    private AccountStatus status;

    // --- User Details ---
    private Long userId;
    private String username;
    private String email;

    // --- Branch Details (optional) ---
    private String branchName;
    private  String ifscCode;
    private  String address;
    private  String contactNumber;

}
