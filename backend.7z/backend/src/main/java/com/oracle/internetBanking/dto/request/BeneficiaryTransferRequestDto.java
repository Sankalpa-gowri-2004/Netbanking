package com.oracle.internetBanking.dto.request;

import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficiaryTransferRequestDto {
    private Long userId;
    private Long beneficiaryId;
    private BigDecimal amount;
    private String description;
}
