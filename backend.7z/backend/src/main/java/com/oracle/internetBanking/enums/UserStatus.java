package com.oracle.internetBanking.enums;

public enum UserStatus {
    ACTIVE, INACTIVE, FROZEN
}