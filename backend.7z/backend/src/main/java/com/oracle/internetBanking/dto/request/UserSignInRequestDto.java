package com.oracle.internetBanking.dto.request;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserSignInRequestDto {
    private String password;
    private String email;
}

