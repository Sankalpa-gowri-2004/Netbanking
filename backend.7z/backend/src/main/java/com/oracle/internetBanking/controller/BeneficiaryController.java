package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.request.BeneficiaryRequestDto;
import com.oracle.internetBanking.dto.request.BeneficiaryTransferRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryResponseDto;
import com.oracle.internetBanking.dto.response.BeneficiaryTransferResponseDto;
import com.oracle.internetBanking.service.BeneficiaryService;
import com.oracle.internetBanking.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/beneficiaries")
@RequiredArgsConstructor
public class BeneficiaryController {

    private final BeneficiaryService beneficiaryService;
    private final TransactionService transactionService;

    @PostMapping
    public ResponseEntity<BeneficiaryResponseDto> addBeneficiary(@RequestBody BeneficiaryRequestDto dto) {
        return ResponseEntity.ok(beneficiaryService.addBeneficiary(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<BeneficiaryResponseDto> updateBeneficiary(
            @PathVariable Long id,
            @RequestBody BeneficiaryRequestDto dto) {
        return ResponseEntity.ok(beneficiaryService.updateBeneficiary(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBeneficiary(@PathVariable Long id) {
        beneficiaryService.deleteBeneficiary(id);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/{id}")
    public ResponseEntity<BeneficiaryResponseDto> getBeneficiary(@PathVariable Long id) {
        return ResponseEntity.ok(beneficiaryService.getBeneficiary(id));
    }


    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BeneficiaryResponseDto>> getUserBeneficiaries(@PathVariable Long userId) {
        return ResponseEntity.ok(beneficiaryService.getUserBeneficiaries(userId));
    }

    @PostMapping("/transfer")
    public ResponseEntity<BeneficiaryTransferResponseDto> transferToBeneficiary(
            @RequestBody BeneficiaryTransferRequestDto dto) {
        return ResponseEntity.ok(transactionService.transferToBeneficiary(dto));
    }


}
