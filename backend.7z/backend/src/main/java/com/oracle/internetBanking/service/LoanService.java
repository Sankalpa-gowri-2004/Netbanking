package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.LoanRequestDto;
import com.oracle.internetBanking.dto.request.RepaymentRequestDto;
import com.oracle.internetBanking.dto.response.LoanResponseDto;
import com.oracle.internetBanking.dto.response.LoanRepaymentDto;

import java.util.List;

public interface LoanService {
    LoanResponseDto createLoan(LoanRequestDto dto);
    LoanResponseDto getLoanById(Long id);
    List<LoanResponseDto> getLoansByUser(Long userId);
    List<LoanRepaymentDto> getRepaymentsByLoan(Long loanId);
    LoanRepaymentDto makeRepayment(Long loanId,RepaymentRequestDto dto);
}
