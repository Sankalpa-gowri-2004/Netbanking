package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.entities.Beneficiary;
import com.oracle.internetBanking.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long> {
    List<Beneficiary> findByUser(User user);
    boolean existsByAccountNumberAndUser(String accountNumber, User user);
}
