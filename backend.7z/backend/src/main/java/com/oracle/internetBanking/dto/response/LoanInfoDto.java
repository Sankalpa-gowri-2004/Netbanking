package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.LoanStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class LoanInfoDto {
    private long loanId;
    private String loanType;
    private BigDecimal principalAmount;
    private BigDecimal interestRate;
    private Integer tenureMonths;
    private Date startDate;
    private BigDecimal remainingAmount;
    private LoanStatus status;
    private String borrowerName;
    private String borrowerEmail;

}
