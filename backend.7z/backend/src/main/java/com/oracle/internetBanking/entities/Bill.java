package com.oracle.internetBanking.entities;

import com.oracle.internetBanking.enums.BillStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


@Entity
@Table(name = "bills")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Bill extends  BaseEntity {

    private String billerName;
    private String accountNumber;
    private BigDecimal amount;
    private java.sql.Date dueDate;

    @Enumerated(EnumType.STRING)
    private BillStatus status = BillStatus.PENDING;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}
