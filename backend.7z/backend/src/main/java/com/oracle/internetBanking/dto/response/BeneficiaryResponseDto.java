package com.oracle.internetBanking.dto.response;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficiaryResponseDto {
    private Long id;
    private String beneficiaryName;
    private String accountNumber;
    private String bankName;
    private String ifscCode;
    private Long userId;
}
