package com.oracle.internetBanking.mapper;

import com.oracle.internetBanking.dto.response.MiniStatementDto;
import com.oracle.internetBanking.dto.response.TransactionResponseDto;
import com.oracle.internetBanking.entities.Transaction;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class TransactionMapper {

    public static TransactionResponseDto toDto(Transaction transaction) {
        return TransactionResponseDto.builder()
                .transactionId(transaction.getId())
                .fromAccountId(Long.valueOf(transaction.getFromAccount().getAccountNumber()))
                .toAccountId(Long.valueOf(transaction.getToAccount().getAccountNumber()))
                .transactionType(transaction.getTransactionType().name())
                .amount(transaction.getAmount())
                .description(transaction.getDescription())
                .status(transaction.getStatus().name())
                .createdAt(transaction.getCreatedAt() != null
                        ? LocalDateTime.ofInstant(transaction.getCreatedAt(), ZoneOffset.UTC)
                        : null)
                .build();
    }

    public static MiniStatementDto toMiniStatementDto(Transaction tx) {
        return MiniStatementDto.builder()
                .transactionId(tx.getId())
                .transactionType(tx.getTransactionType())
                .amount(tx.getAmount())
                .description(tx.getDescription())
                .createdAt(tx.getCreatedAt() != null
                        ? LocalDateTime.ofInstant(tx.getCreatedAt(), ZoneOffset.UTC)
                        : null).build();

    }

}


