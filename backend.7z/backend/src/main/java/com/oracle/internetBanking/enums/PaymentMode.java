package com.oracle.internetBanking.enums;

public enum PaymentMode {
    UPI, CARD, NET_BANKING, CASH, CHEQUE
}
