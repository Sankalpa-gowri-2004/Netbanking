package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.AccountRequestDto;
import com.oracle.internetBanking.dto.request.TransactionFilterCriteria;
import com.oracle.internetBanking.dto.response.AccountResponseDto;
import com.oracle.internetBanking.dto.response.AccountSummaryDto;
import com.oracle.internetBanking.dto.response.DetailedUserDto;
import com.oracle.internetBanking.dto.response.MiniStatementDto;
import com.oracle.internetBanking.entities.Account;
import com.oracle.internetBanking.entities.Branch;
import com.oracle.internetBanking.entities.Transaction;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.exception.AccountNotFoundException;
import com.oracle.internetBanking.exception.BranchNotFoundException;
import com.oracle.internetBanking.mapper.AccountMapper;
import com.oracle.internetBanking.mapper.TransactionMapper;
import com.oracle.internetBanking.repository.AccountRepository;
import com.oracle.internetBanking.repository.BranchRepository;
import com.oracle.internetBanking.repository.TransactionRepository;
import com.oracle.internetBanking.repository.UserRepository;
import com.oracle.internetBanking.service.AccountService;
import com.oracle.internetBanking.specifications.AccountSpecifications;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final UserRepository userRepository;
    private final TransactionRepository transactionRepository;
    private final BranchRepository branchRepository;

    @Override
    @Transactional
    public AccountResponseDto createAccount(AccountRequestDto dto) {

        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        log.info("Ifsc Recieved is: {}", dto.getIfscCode());

        Branch branch=branchRepository.findByIfscCode(dto.getIfscCode()).orElseThrow(()->new BranchNotFoundException("Branch not found"));

        Account account = new Account();
        account.setUser(user);
        account.setAccountType(dto.getAccountType());
        account.setAccountNumber(generateAccountNumber());
        account.setBalance(BigDecimal.valueOf(0.0));
        account.setBranch(branch);
        account.setCurrency(dto.getCurrency() != null ? dto.getCurrency() : "INR");

        Account saved = accountRepository.save(account);

        return AccountResponseDto.builder()
                .id(saved.getId())
                .accountNumber(saved.getAccountNumber())
                .accountType(saved.getAccountType())
                .balance(saved.getBalance())
                .currency(saved.getCurrency())
                .build();
    }

    private String generateAccountNumber() {
        return String.valueOf(System.currentTimeMillis()).substring(0, 12);
    }

    @Override
    public List<AccountSummaryDto> getAccountsByUserId(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AccountNotFoundException("User not found"));

        List<Account> accounts = accountRepository.findByUserAndStatusAndBranch_BranchNameNot(user,AccountStatus.ACTIVE, "Generic Bank Branch");

        return accounts.stream()
                .map(AccountMapper::toSummaryDto)
                .collect(Collectors.toList());

//        return accountRepository.findByUser(user)
//                .stream()
//                .map(AccountMapper::toSummaryDto)
//                .collect(Collectors.toList());
    }

    @Override
    public List<MiniStatementDto> getMiniStatement(Long accountId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));
        return transactionRepository
                .findTop10ByFromAccountOrToAccountOrderByCreatedAtDesc(account, account)
                .stream()
                .map(TransactionMapper::toMiniStatementDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<MiniStatementDto> getFilteredTransactions(Long accountId, TransactionFilterCriteria filterCriteria) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));

        List<Transaction> transactions = transactionRepository.findByFromAccountOrToAccount(account, account);

        return transactions.stream()
                .filter(tx -> (filterCriteria.getFromDate() == null ||
                        !tx.getCreatedAt()
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate()
                                .isBefore(filterCriteria.getFromDate())))
                .filter(tx -> (filterCriteria.getToDate() == null ||
                        !tx.getCreatedAt()
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate()
                                .isAfter(filterCriteria.getToDate())))
                .filter(tx -> (filterCriteria.getType() == null || tx.getTransactionType() == filterCriteria.getType()))
                .filter(tx -> (filterCriteria.getMinAmount() == null ||
                        tx.getAmount().compareTo(filterCriteria.getMinAmount()) >= 0))
                .filter(tx -> (filterCriteria.getMaxAmount() == null ||
                        tx.getAmount().compareTo(filterCriteria.getMaxAmount()) <= 0))
                .map(TransactionMapper::toMiniStatementDto)
                .collect(Collectors.toList());
    }




    public DetailedUserDto getDetailedInfo(Long accountId) {

        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found with id: " + accountId));

        return DetailedUserDto.builder()
                .accountNumber(account.getAccountNumber())
                .accountType(account.getAccountType())
                .balance(account.getBalance())
                .currency(account.getCurrency())
                .status(account.getStatus())
                .userId(account.getUser().getId())
                .username(account.getUser().getUsername())
                .email(account.getUser().getEmail())
                .contactNumber(account.getBranch().getContactNumber())
                .ifscCode(account.getBranch().getIfscCode())
                .address(account.getBranch().getAddress())
                .branchName(account.getBranch().getBranchName())
                .build();
    }




}
