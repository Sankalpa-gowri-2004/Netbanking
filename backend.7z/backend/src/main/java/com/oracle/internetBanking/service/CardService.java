package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.CardRequestDto;
import com.oracle.internetBanking.dto.response.CardResponseDto;

import java.util.List;

public interface CardService {
    List<CardResponseDto> getActiveCards(Long userId);
    CardResponseDto blockCard(String cardId);
    CardResponseDto requestNewCard(Long userId, CardRequestDto dto);
}
