package com.oracle.internetBanking.mapper;



import com.oracle.internetBanking.dto.response.AccountSummaryDto;
import com.oracle.internetBanking.entities.Account;

public class AccountMapper {
    public static AccountSummaryDto toSummaryDto(Account account) {
        return AccountSummaryDto.builder()
                .accountId(account.getId())
                .accountNumber(account.getAccountNumber())
                .accountType(account.getAccountType())
                .balance(account.getBalance())
                .currency(account.getCurrency())
                .status(account.getStatus())
                .build();
    }
}

