package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.dto.response.CardInfoDto;
import com.oracle.internetBanking.entities.Card;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.enums.CardType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CardRepository extends JpaRepository<Card, Long> {
    List<Card> findByUserAndStatus(User user, CardStatus status);
    boolean existsByUserIdAndCardType(Long userId, CardType cardType);
    Optional<Card> findByCardNumber(String cardNumber);
    @Query("SELECT new com.oracle.internetBanking.dto.response.CardInfoDto(" +
            " c.cardNumber, c.cardType, c.expiryDate, c.status, u.username, a.accountNumber)" +
            " FROM Card c" +
            " JOIN c.user u" +
            " JOIN c.account a")
    List<CardInfoDto> findAllCardInfo();
}
