package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.entities.Account;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long>, JpaSpecificationExecutor<Account> {
    Optional<Account> findById(Long fromAccountId);
    Optional<Account> findByAccountNumber(String accountNumber);
    List<Account> findByUser(User user);

    Optional<Account> findByUserIdAndAccountType(Long userId, AccountType accountType);

    Optional<Account> findByUserIdAndAccountTypeAndStatus(Long userId, AccountType accountType, AccountStatus accountStatus);

    List<Account> findByUserId(Long userId);
    long count();

    List<Account> findByUserAndBranch_BranchNameNot(User user, String branchName);

    List<Account> findByUserAndStatusAndBranch_BranchNameNot(User user, AccountStatus accountStatus, String genericBankBranch);
}
