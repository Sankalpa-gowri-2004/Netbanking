package com.oracle.internetBanking.dto.response;

/**
 * @author mirzbeg
 **/


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminDashboardResponse {
    private long totalAccounts;
    private long totalLoans;
    private long pendingApprovals;
    private long totalBranches;
    private Map<String, Double> loansPerBranch;
}
