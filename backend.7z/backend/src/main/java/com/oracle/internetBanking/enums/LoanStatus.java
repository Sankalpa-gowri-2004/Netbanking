package com.oracle.internetBanking.enums;

public enum LoanStatus {
    ACTIVE, CLOSED,PENDING
}