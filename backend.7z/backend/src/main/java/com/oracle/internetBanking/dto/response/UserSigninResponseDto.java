package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mirzbeg
 **/
@Builder
@Setter
@Getter
@AllArgsConstructor
public class UserSigninResponseDto {
    private Long id;
    private String name;
    private String email;
    private Role role;
    private String token;
    private boolean success;
}
