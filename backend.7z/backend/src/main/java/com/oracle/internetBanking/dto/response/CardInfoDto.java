package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.enums.CardType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class CardInfoDto {
    private String cardNumber;
    private CardType cardType;
    private Date expiryDate;
    private CardStatus status;
    private String cardHolderName;
    private String accountNumber;
}
