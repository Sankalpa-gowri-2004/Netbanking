package com.oracle.internetBanking.controller;


import com.oracle.internetBanking.dto.request.LoanRequestDto;
import com.oracle.internetBanking.dto.request.RepaymentRequestDto;
import com.oracle.internetBanking.dto.response.LoanResponseDto;
import com.oracle.internetBanking.dto.response.LoanRepaymentDto;
import com.oracle.internetBanking.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/loans")
@RequiredArgsConstructor
public class LoanController {

    private final LoanService loanService;

    @PostMapping
    public ResponseEntity<LoanResponseDto> createLoan(@RequestBody LoanRequestDto dto) {
        return ResponseEntity.ok(loanService.createLoan(dto));
    }

    @GetMapping("/{loanId}")
    public ResponseEntity<LoanResponseDto> getLoanById(@PathVariable Long loanId) {
        return ResponseEntity.ok(loanService.getLoanById(loanId));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<LoanResponseDto>> getLoansByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(loanService.getLoansByUser(userId));
    }

    @GetMapping("/{loanId}/repayments")
    public ResponseEntity<List<LoanRepaymentDto>> getRepaymentsByLoan(@PathVariable Long loanId) {
        return ResponseEntity.ok(loanService.getRepaymentsByLoan(loanId));
    }

    @PostMapping("/{loanId}/repayments")
    public ResponseEntity<LoanRepaymentDto> makeRepayment(
            @PathVariable Long loanId,
            @RequestBody RepaymentRequestDto dto) {
        return ResponseEntity.ok(loanService.makeRepayment(loanId,dto));
    }

}

