package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserSignUpRequestDto {
    private String username;
    private String email;
    private String password;
    private Role role;
}

