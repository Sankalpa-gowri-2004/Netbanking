package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.ApiResponse;
import com.oracle.internetBanking.dto.request.TransactionSearchCriteria;
import com.oracle.internetBanking.dto.request.TransferRequestDto;
import com.oracle.internetBanking.dto.response.TransactionResponseDto;
import com.oracle.internetBanking.dto.response.UserTransactionResponseDto;
import com.oracle.internetBanking.service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping("/transfer")
    public ResponseEntity<ApiResponse<TransactionResponseDto>> transferFunds(@RequestBody TransferRequestDto requestDto) {
        log.info("Received transfer request: {}", requestDto);

        TransactionResponseDto result = transactionService.transferFunds(requestDto);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>("Transfer successful", result));

    }

//    @GetMapping("/from/{accountNumber}")
//    public ResponseEntity<List<UserTransactionResponseDto>> getTransactionsByFromAccount(@PathVariable String accountNumber) {
//        List<UserTransactionResponseDto> transactions = transactionService.getTransactionsByFromAccount(accountNumber);
//        return ResponseEntity.ok(transactions);
//    }

    @GetMapping("/from/{accountNumber}")
    public ResponseEntity<List<UserTransactionResponseDto>> getTransactionsByFromAccount(
            @PathVariable String accountNumber,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate) {

        TransactionSearchCriteria criteria = new TransactionSearchCriteria();
        criteria.setType(type);
        criteria.setStatus(status);
        criteria.setFromDate(fromDate);
        criteria.setToDate(toDate);

        List<UserTransactionResponseDto> transactions = transactionService.getTransactionsByFromAccount(accountNumber, criteria);
        return ResponseEntity.ok(transactions);
    }

    @PostMapping("/search")
    public ResponseEntity<List<TransactionResponseDto>> searchTransactions(@RequestBody TransactionSearchCriteria criteria) {
        List<TransactionResponseDto> transactions = transactionService.searchTransactions(criteria);
        return ResponseEntity.ok(transactions);
    }

}
