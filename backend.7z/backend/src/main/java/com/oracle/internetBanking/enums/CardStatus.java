package com.oracle.internetBanking.enums;

public enum CardStatus {
    ACTIVE, BLOCKED, EXPIRED
}
