package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.request.UserSignInRequestDto;
import com.oracle.internetBanking.dto.request.OtpVerifyRequestDto;
import com.oracle.internetBanking.dto.request.UserSignUpRequestDto;
import com.oracle.internetBanking.dto.response.UserResponseDto;
import com.oracle.internetBanking.dto.response.OtpResponseDto;
import com.oracle.internetBanking.dto.response.UserSigninResponseDto;
import com.oracle.internetBanking.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final UserService userService;

    // Step 1: Credentials -> send OTP
    @PostMapping("/login")
    public ResponseEntity<OtpResponseDto> initiateLogin(@RequestBody UserSignInRequestDto signInDto) {
        userService.initiateLogin(signInDto);
        log.info("User is trying to login");
        return ResponseEntity.status(HttpStatus.OK).body(new OtpResponseDto("OTP sent to registered email",true));
    }

    // Step 2: Verify OTP -> return JWT + user
    @PostMapping("/verify-otp")
    public ResponseEntity<UserSigninResponseDto> verifyOtp(@RequestBody OtpVerifyRequestDto verifyDto) {
        UserSigninResponseDto resp = userService.verifyOtpAndLogin(verifyDto);
        return ResponseEntity.ok(resp);
    }


    @PostMapping("/register")
    public ResponseEntity<UserResponseDto> register(@RequestBody UserSignUpRequestDto dto) {
        log.info("Registering user:" );
        UserResponseDto response = userService.createUser(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

}
