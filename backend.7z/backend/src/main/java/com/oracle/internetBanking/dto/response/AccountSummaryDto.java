package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountSummaryDto {
    private Long accountId;
    private String accountNumber;
    private AccountType accountType;
    private BigDecimal balance;
    private String currency;
    private AccountStatus status;
}
