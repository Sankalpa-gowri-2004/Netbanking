package com.oracle.internetBanking.entities;


import com.oracle.internetBanking.enums.TransactionStatus;
import com.oracle.internetBanking.enums.TransactionType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Table(name = "beneficiaries")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Beneficiary extends  BaseEntity {

    private String beneficiaryName;
    private String accountNumber;
    private String bankName;
    private String ifscCode;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

