package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.LoanStatus;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Date;

@Getter
@Setter
public class LoanUpdateDto {
    private LoanStatus status;
    private BigDecimal principalAmount;
    private BigDecimal interestRate;
    private Integer tenureMonths;
    private Date startDate;
    private BigDecimal remainingAmount;
}
