package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.dto.response.LoanInfoDto;
import com.oracle.internetBanking.entities.Loan;
import com.oracle.internetBanking.enums.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {
    List<Loan> findByUserId(Long userId);

    long countByStatus(LoanStatus status);

    @Query(value = """
        SELECT b.branch_name AS branchName, COUNT(l.id) AS loanCount
        FROM loans l
        JOIN users u ON l.user_id = u.id
        JOIN accounts a ON u.id = a.user_id
        JOIN branches b ON a.branch_id = b.id
        GROUP BY b.branch_name
        """, nativeQuery = true)
    List<Object[]> countLoansPerBranch();


    @Query("SELECT new com.oracle.internetBanking.dto.response.LoanInfoDto(" +
            "l.id,l.loanType, l.principalAmount, l.interestRate, l.tenureMonths, " +
            "l.startDate, l.remainingAmount, l.status, u.username, u.email)" +
            " FROM Loan l JOIN l.user u")
    List<LoanInfoDto> findAllLoanInfo();
}
