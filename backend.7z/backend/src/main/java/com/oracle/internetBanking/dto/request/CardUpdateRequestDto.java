package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.enums.CardType;
import lombok.Data;

import java.sql.Date;


@Data
public class CardUpdateRequestDto {
    private CardType cardType;
    private Date expiryDate;
    private CardStatus status;
    private String username;
    private String accountNumber;
}
