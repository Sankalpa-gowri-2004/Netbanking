package com.oracle.internetBanking.enums;

public enum BillStatus {
    PENDING, PAID
}
