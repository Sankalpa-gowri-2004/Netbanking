package com.oracle.internetBanking.dto.request;
import lombok.Data;

@Data
public class OtpVerifyRequestDto {
    private String email;
    private String otp;
}
