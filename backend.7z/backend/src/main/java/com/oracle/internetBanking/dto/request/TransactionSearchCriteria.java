package com.oracle.internetBanking.dto.request;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionSearchCriteria {
    private String type;       // TRANSFER, DEPOSIT, etc.
    private String status;     // SUCCESS, PENDING, etc.
    private String fromDate;   // YYYY-MM-DD
    private String toDate;     // YYYY-MM-DD
    private Long accountId;    // optional filter
}