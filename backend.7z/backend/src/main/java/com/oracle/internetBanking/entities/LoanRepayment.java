package com.oracle.internetBanking.entities;

import com.oracle.internetBanking.enums.PaymentMode;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Date;

@Entity
@Table(name = "loan_repayments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Builder
public class LoanRepayment extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "loan_id", nullable = false)
    private Loan loan;

    private BigDecimal amountPaid;
    private Date paymentDate;
    private PaymentMode paymentMode;

}
