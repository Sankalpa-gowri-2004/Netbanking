package com.oracle.internetBanking.enums;

public enum TransactionType {
    TRANSFER, BILL_PAYMENT, DEPOSIT, WITHDRAWAL, LOAN_REPAYMENT,EXTERNAL_TRANSFER
}
