package com.oracle.internetBanking.mapper;

import com.oracle.internetBanking.dto.request.BranchRequestDto;
import com.oracle.internetBanking.dto.response.BranchResponseDto;
import com.oracle.internetBanking.entities.Branch;

public class BranchMapper {

    public static Branch toEntity(BranchRequestDto dto) {
        Branch branch = new Branch();
        branch.setIfscCode(dto.getIfscCode());
        branch.setBranchName(dto.getBranchName());
        branch.setAddress(dto.getAddress());
        branch.setCity(dto.getCity());
        branch.setState(dto.getState());
        branch.setContactNumber(dto.getContactNumber());
        return branch;
    }

    public static BranchResponseDto toDto(Branch branch) {
        return BranchResponseDto.builder()
                .id(branch.getId())
                .ifscCode(branch.getIfscCode())
                .branchName(branch.getBranchName())
                .address(branch.getAddress())
                .city(branch.getCity())
                .state(branch.getState())
                .contactNumber(branch.getContactNumber())
                .build();
    }
}
