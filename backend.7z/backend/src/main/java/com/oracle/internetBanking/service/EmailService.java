package com.oracle.internetBanking.service;

import java.time.LocalDateTime;

public interface EmailService {
    void sendOtpEmail(String to, String otp, int expiryMinutes);
}
