package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.LoanRequestDto;
import com.oracle.internetBanking.dto.request.RepaymentRequestDto;
import com.oracle.internetBanking.dto.response.LoanResponseDto;
import com.oracle.internetBanking.dto.response.LoanRepaymentDto;
import com.oracle.internetBanking.entities.Loan;
import com.oracle.internetBanking.entities.LoanRepayment;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.enums.LoanStatus;
import com.oracle.internetBanking.exception.InvalidRepaymentException;
import com.oracle.internetBanking.exception.LoanNotFoundException;
import com.oracle.internetBanking.mapper.LoanMapper;
import com.oracle.internetBanking.repository.LoanRepository;
import com.oracle.internetBanking.repository.LoanRepaymentRepository;
import com.oracle.internetBanking.repository.UserRepository;
import com.oracle.internetBanking.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LoanServiceImpl implements LoanService {

    private final LoanRepository loanRepository;
    private final LoanRepaymentRepository repaymentRepository;
    private final UserRepository userRepository;

    @Override
    public LoanResponseDto createLoan(LoanRequestDto dto) {
        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new LoanNotFoundException("User not found for loan creation"));

        Loan loan = LoanMapper.toEntity(dto);
        loan.setUser(user);
        Loan saved = loanRepository.save(loan);

        return LoanMapper.toDto(saved);
    }

    @Override
    public LoanResponseDto getLoanById(Long id) {
        Loan loan = loanRepository.findById(id)
                .orElseThrow(() -> new LoanNotFoundException("Loan not found with ID: " + id));
        return LoanMapper.toDto(loan);
    }

    @Override
    public List<LoanResponseDto> getLoansByUser(Long userId) {
        return loanRepository.findByUserId(userId)
                .stream()
                .map(LoanMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<LoanRepaymentDto> getRepaymentsByLoan(Long loanId) {
        List<LoanRepayment> repayments = repaymentRepository.findByLoanId(loanId);
        return repayments.stream()
                .map(LoanMapper::toRepaymentDto)
                .collect(Collectors.toList());
    }

    @Override
    public LoanRepaymentDto makeRepayment(Long loanId,RepaymentRequestDto dto) {

        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException("Loan not found with ID: " + loanId));


        BigDecimal newRemaining = loan.getRemainingAmount().subtract(dto.getAmountPaid());
        if (newRemaining.compareTo(BigDecimal.ZERO) < 0) {
            throw new InvalidRepaymentException("Repayment exceeds outstanding loan balance");
        }
        loan.setRemainingAmount(newRemaining);

        if (newRemaining.compareTo(BigDecimal.ZERO) == 0) {
            loan.setStatus(LoanStatus.CLOSED);
        }

        loanRepository.save(loan);


        LoanRepayment repayment = LoanRepayment.builder()
                .loan(loan)
                .amountPaid(dto.getAmountPaid())
                .paymentDate(new java.sql.Date(System.currentTimeMillis()))
                .paymentMode(dto.getPaymentMode())
                .build();

        LoanRepayment saved = repaymentRepository.save(repayment);

        return LoanMapper.toRepaymentDto(saved);
    }
}
