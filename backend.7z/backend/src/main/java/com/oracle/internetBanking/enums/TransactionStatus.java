package com.oracle.internetBanking.enums;

public enum TransactionStatus {
    SUCCESS, PENDING, FAILED
}

