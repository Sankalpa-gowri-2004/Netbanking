package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.PaymentMode;
import lombok.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepaymentRequestDto {
    private BigDecimal amountPaid;
    private PaymentMode paymentMode; // NETBANKING, UPI, CARD, etc.
}
