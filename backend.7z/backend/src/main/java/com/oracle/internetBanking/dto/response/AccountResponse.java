package com.oracle.internetBanking.dto.response;

import java.math.BigDecimal;

public record AccountResponse(
        String accountNumber,
        String holderName,
        String type,
        String branch,
        String status,
        BigDecimal balance
) {}

