package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.enums.CardType;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CardResponseDto {
    private Long cardId;
    private String cardNumber;
    private CardType cardType;
    private LocalDate expiryDate;
    private CardStatus status;
    private Long userId;
    private Long accountId;
    private String holder;
}
