package com.oracle.internetBanking.dto.request;

import lombok.*;
import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequestDto {
    private String  fromAccountId;
    private String toAccountId;
    private BigDecimal amount;
    private String description;
}
