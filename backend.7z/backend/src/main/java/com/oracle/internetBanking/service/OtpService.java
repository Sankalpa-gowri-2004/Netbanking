package com.oracle.internetBanking.service;

public interface OtpService {
    void generateAndSendOtpForLogin(String email);
    String validateOtpAndMarkUsed(String email, String otp);
}

