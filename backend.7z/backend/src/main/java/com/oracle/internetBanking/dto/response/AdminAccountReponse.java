package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import jakarta.persistence.Id;
import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminAccountReponse {
    private Long id;
    private String accountNumber;
    private String username;
    private String branchName;
    private AccountType accountType;
    private BigDecimal balance;
    private AccountStatus status;

    @Override
    public String toString() {
        return "AdminAccountReponse{" +
                "id=" + id +
                ", accountNumber='" + accountNumber + '\'' +
                ", username='" + username + '\'' +
                ", branchName='" + branchName + '\'' +
                ", accountType=" + accountType +
                ", balance=" + balance +
                ", status=" + status +
                '}';
    }
}
