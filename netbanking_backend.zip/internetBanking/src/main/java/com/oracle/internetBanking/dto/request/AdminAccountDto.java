package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class AdminAccountDto {
    private String branchName;
    private String username;
    private AccountType accountType;
    private BigDecimal balance;
    private AccountStatus status;
    private String accountNumber;
}
