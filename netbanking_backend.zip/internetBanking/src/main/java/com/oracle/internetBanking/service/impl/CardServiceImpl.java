package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.CardRequestDto;
import com.oracle.internetBanking.dto.response.CardResponseDto;
import com.oracle.internetBanking.entities.*;
import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.exception.*;
import com.oracle.internetBanking.mapper.CardMapper;
import com.oracle.internetBanking.repository.*;
import com.oracle.internetBanking.service.CardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CardServiceImpl implements CardService {

    private final CardRepository cardRepository;
    private final UserRepository userRepository;
    private final AccountRepository accountRepository;

    @Override
    public List<CardResponseDto> getActiveCards(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return cardRepository.findByUserAndStatus(user, CardStatus.ACTIVE)
                .stream()
                .map(CardMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public CardResponseDto blockCard(String cardId) {

        Card card = cardRepository.findByCardNumber(cardId)
                .orElseThrow(() -> new RuntimeException("Card not found"));

        if (card.getStatus() == CardStatus.BLOCKED) {
            throw new RuntimeException("Card is already blocked");
        }

        card.setStatus(CardStatus.BLOCKED);

//        cardRepository.save(card);
        cardRepository.delete(card);

        return CardMapper.toDto(card);
    }

    @Override
    public CardResponseDto requestNewCard(Long userId, CardRequestDto dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

//        Account account = accountRepository.findByAccountNumber(dto.getAccountId())
//                .orElseThrow(() -> new AccountNotFoundException("Account not found"));

        Account account = accountRepository
                .findByUserIdAndAccountTypeAndStatus(userId, AccountType.SAVINGS, AccountStatus.ACTIVE)
                .orElseThrow(() -> new AccountNotFoundException(
                        "No SAVINGS account found for userId: " + userId
                ));

        System.out.println(account.getAccountNumber());

        if(cardRepository.existsByUserIdAndCardType(userId, dto.getCardType())) {
            throw new CardAlreadyExistsException("Card of this type already exists for the user");
        }

        Card card = new Card();
        card.setCardNumber(generateCardNumber());
        card.setCardType(dto.getCardType());
        card.setExpiryDate(Date.valueOf(LocalDate.now().plusYears(5)));
        card.setStatus(CardStatus.BLOCKED);
        card.setUser(user);
        card.setAccount(account);

        cardRepository.save(card);

        return CardMapper.toDto(card);
    }

    private String generateCardNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}
