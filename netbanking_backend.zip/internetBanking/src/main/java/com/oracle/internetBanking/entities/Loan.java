package com.oracle.internetBanking.entities;


import com.oracle.internetBanking.enums.LoanStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


import java.sql.Date;

@Entity
@Table(name = "loans")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Loan extends BaseEntity {

    @Enumerated(EnumType.STRING)
    private LoanStatus status = LoanStatus.PENDING;

    @Column(nullable = false)
    private String loanType;

    @Column(nullable = false)
    private BigDecimal principalAmount;

    @Column(nullable = false)
    private BigDecimal interestRate;

    private Integer tenureMonths;

    private Date startDate;

    /**
     * Remaining balance of the loan including interest.
     * This will be reduced with each repayment.
     */
    @Column(nullable = false)
    private BigDecimal remainingAmount;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

