package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.BeneficiaryRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryResponseDto;
import com.oracle.internetBanking.entities.Beneficiary;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.exception.BeneficiaryNotFoundException;
import com.oracle.internetBanking.exception.DuplicateBeneficiaryException;
import com.oracle.internetBanking.exception.InvalidIfscCodeException;
import com.oracle.internetBanking.mapper.BeneficiaryMapper;
import com.oracle.internetBanking.repository.BeneficiaryRepository;
import com.oracle.internetBanking.repository.UserRepository;
import com.oracle.internetBanking.service.BeneficiaryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BeneficiaryServiceImpl implements BeneficiaryService {

    private final BeneficiaryRepository beneficiaryRepository;
    private final UserRepository userRepository;

    private static final Pattern IFSC_PATTERN = Pattern.compile("^[A-Z]{4}0[A-Z0-9]{6}$");

    @Override
    public BeneficiaryResponseDto addBeneficiary(BeneficiaryRequestDto dto) {
        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new BeneficiaryNotFoundException("User not found with id: " + dto.getUserId()));

        if (!IFSC_PATTERN.matcher(dto.getIfscCode()).matches()) {
            throw new InvalidIfscCodeException("Invalid IFSC code: " + dto.getIfscCode());
        }

        if (beneficiaryRepository.existsByAccountNumberAndUser(dto.getAccountNumber(), user)) {
            throw new DuplicateBeneficiaryException("Beneficiary already exists for account: " + dto.getAccountNumber());
        }

        Beneficiary beneficiary = BeneficiaryMapper.toEntity(dto);
        beneficiary.setUser(user);
        Beneficiary saved = beneficiaryRepository.save(beneficiary);

        return BeneficiaryMapper.toDto(saved);
    }

    @Override
    public BeneficiaryResponseDto updateBeneficiary(Long id, BeneficiaryRequestDto dto) {
        Beneficiary beneficiary = beneficiaryRepository.findById(id)
                .orElseThrow(() -> new BeneficiaryNotFoundException("Beneficiary not found with id: " + id));

        beneficiary.setBeneficiaryName(dto.getBeneficiaryName());
        beneficiary.setAccountNumber(dto.getAccountNumber());
        beneficiary.setBankName(dto.getBankName());

        if (!IFSC_PATTERN.matcher(dto.getIfscCode()).matches()) {
            throw new InvalidIfscCodeException("Invalid IFSC code: " + dto.getIfscCode());
        }
        beneficiary.setIfscCode(dto.getIfscCode());

        Beneficiary updated = beneficiaryRepository.save(beneficiary);
        return BeneficiaryMapper.toDto(updated);
    }

    @Override
    public void deleteBeneficiary(Long id) {
        Beneficiary beneficiary = beneficiaryRepository.findById(id)
                .orElseThrow(() -> new BeneficiaryNotFoundException("Beneficiary not found with id: " + id));
        beneficiaryRepository.delete(beneficiary);
    }

    @Override
    public BeneficiaryResponseDto getBeneficiary(Long id) {
        Beneficiary beneficiary = beneficiaryRepository.findById(id)
                .orElseThrow(() -> new BeneficiaryNotFoundException("Beneficiary not found with id: " + id));
        return BeneficiaryMapper.toDto(beneficiary);
    }

    @Override
    public List<BeneficiaryResponseDto> getUserBeneficiaries(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new BeneficiaryNotFoundException("User not found with id: " + userId));

        return beneficiaryRepository.findByUser(user)
                .stream()
                .map(BeneficiaryMapper::toDto)
                .collect(Collectors.toList());
    }
}
