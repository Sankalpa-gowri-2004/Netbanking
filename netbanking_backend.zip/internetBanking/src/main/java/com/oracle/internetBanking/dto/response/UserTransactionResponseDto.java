package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.TransactionStatus;
import com.oracle.internetBanking.enums.TransactionType;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserTransactionResponseDto {
    private Long transactionId;
    private LocalDateTime date;
    private String description;
    private TransactionType type;
    private BigDecimal amount;
    private TransactionStatus status;
}

