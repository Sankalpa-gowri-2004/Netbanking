package com.oracle.internetBanking.dto.response;

import com.oracle.internetBanking.enums.PaymentMode;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanRepaymentDto {
    private Long id;
    private BigDecimal amountPaid;
    private Date paymentDate;
    private PaymentMode paymentMode;
}
