package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.entities.UserOtp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OtpRepository extends JpaRepository<UserOtp, Long> {

    Optional<UserOtp> findFirstByEmailAndOtpAndUsedFalse(String email, String otp);

    Optional<UserOtp> findTopByEmailAndUsedFalseOrderByCreatedAtDesc(String email);
}
