package com.oracle.internetBanking.exception;

public class InvalidIfscCodeException extends RuntimeException {
    public InvalidIfscCodeException(String message) {
        super(message);
    }
}
