package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.BeneficiaryTransferRequestDto;
import com.oracle.internetBanking.dto.request.TransactionSearchCriteria;
import com.oracle.internetBanking.dto.request.TransferRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryTransferResponseDto;
import com.oracle.internetBanking.dto.response.TransactionResponseDto;
import com.oracle.internetBanking.dto.response.UserTransactionResponseDto;

import java.util.List;

public interface TransactionService {
    TransactionResponseDto transferFunds(TransferRequestDto requestDto);
    List<TransactionResponseDto> searchTransactions(TransactionSearchCriteria criteria);
    BeneficiaryTransferResponseDto transferToBeneficiary(BeneficiaryTransferRequestDto dto);
     List<UserTransactionResponseDto> getTransactionsByFromAccount(String accountNumber,TransactionSearchCriteria transactionSearchCriteria) ;
}

