package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.BeneficiaryTransferRequestDto;
import com.oracle.internetBanking.dto.request.TransactionSearchCriteria;
import com.oracle.internetBanking.dto.request.TransferRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryTransferResponseDto;
import com.oracle.internetBanking.dto.response.TransactionResponseDto;
import com.oracle.internetBanking.dto.response.UserTransactionResponseDto;
import com.oracle.internetBanking.entities.*;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.enums.TransactionStatus;
import com.oracle.internetBanking.enums.TransactionType;
import com.oracle.internetBanking.exception.*;
import com.oracle.internetBanking.mapper.TransactionMapper;
import com.oracle.internetBanking.repository.*;
import com.oracle.internetBanking.service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private  final  UserRepository userRepository;
    private  final  BeneficiaryRepository beneficiaryRepository;


    @Override
    @Transactional
    public TransactionResponseDto transferFunds(TransferRequestDto requestDto) {
        log.info("Initiating transfer from account {} to account {}",
                requestDto.getFromAccountId(), requestDto.getToAccountId());

        // Fetch sender account
        Account fromAccount = accountRepository.findByAccountNumber(requestDto.getFromAccountId())
                .orElseThrow(() -> new InvalidAccountException("Sender account not found"));

        // Check balance
        if (fromAccount.getBalance().compareTo(requestDto.getAmount()) < 0) {
            throw new InsufficientBalanceException("Insufficient balance in sender account");
        }

        // Deduct balance from sender
        fromAccount.setBalance(fromAccount.getBalance().subtract(requestDto.getAmount()));
        accountRepository.save(fromAccount);

        // Fetch receiver account (may be external)
        Optional<Account> toAccountOpt = accountRepository.findByAccountNumber(requestDto.getToAccountId());

        if (toAccountOpt.isPresent()) {
            // Internal transfer: credit balance
            Account toAccount = toAccountOpt.get();
            toAccount.setBalance(toAccount.getBalance().add(requestDto.getAmount()));
            accountRepository.save(toAccount);
            log.info("Internal transfer: Receiver balance updated.");
            Transaction transaction2 = Transaction.builder()
                    .fromAccount(toAccount)
                    .toAccount(fromAccount)
                    .transactionType( TransactionType.DEPOSIT)
                    .amount(requestDto.getAmount())
                    .description(requestDto.getDescription())
                    .status(TransactionStatus.SUCCESS)
                    .build();
            transactionRepository.save(transaction2);

        } else {
            // External transfer: no balance update, just log
            log.info("External transfer: Receiver account {} not in our bank. Skipping balance update.",
                    requestDto.getToAccountId());
        }

        // Record transaction
        Transaction transaction = Transaction.builder()
                .fromAccount(fromAccount)
                .toAccount(toAccountOpt.orElse(null)) // null if external
                .transactionType(toAccountOpt.isPresent() ? TransactionType.WITHDRAWAL : TransactionType.EXTERNAL_TRANSFER)
                .amount(requestDto.getAmount())
                .description(requestDto.getDescription())
                .status(TransactionStatus.SUCCESS)
                .build();

        transactionRepository.save(transaction);
        log.info("Transaction recorded successfully.");

        return TransactionMapper.toDto(transaction);
    }


    @Override
    public List<TransactionResponseDto> searchTransactions(TransactionSearchCriteria criteria) {
        // Simple filter (extend to use Specification or Criteria API for real-world search)
        List<Transaction> transactions = transactionRepository.findAll();
        return transactions.stream()
                .filter(t -> criteria.getAccountId() == null ||
                        (t.getFromAccount() != null && t.getFromAccount().getId().equals(criteria.getAccountId())) ||
                        (t.getToAccount() != null && t.getToAccount().getId().equals(criteria.getAccountId())))
                .filter(t -> criteria.getType() == null || t.getTransactionType().name().equals(criteria.getType()))
                .filter(t -> criteria.getStatus() == null || t.getStatus().name().equals(criteria.getStatus()))
                .filter(t -> {
                    if (criteria.getFromDate() == null && criteria.getToDate() == null) return true;

                    LocalDate date = t.getCreatedAt()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

                    LocalDate from = criteria.getFromDate() != null ? LocalDate.parse(criteria.getFromDate()) : LocalDate.MIN;
                    LocalDate to = criteria.getToDate() != null ? LocalDate.parse(criteria.getToDate()) : LocalDate.MAX;

                    return !date.isBefore(from) && !date.isAfter(to);
                })
                .map(TransactionMapper::toDto)
                .collect(Collectors.toList());
    }


    @Override
    @Transactional
    public BeneficiaryTransferResponseDto transferToBeneficiary(BeneficiaryTransferRequestDto dto) {
        // 1. Validate user
        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new BeneficiaryNotFoundException("User not found with id: " + dto.getUserId()));

        // 2. Validate account
        Account fromAccount = accountRepository.findByUserIdAndAccountType(dto.getUserId(), AccountType.SAVINGS)
                .orElseThrow(() -> new AccountNotFoundException("User with id " + dto.getUserId() + " does not have the specified  Savings account"));



        if (!fromAccount.getStatus().name().equals("ACTIVE")) {
            throw new InvalidRequestException("Account is not active");
        }

        // 3. Validate beneficiary
        Beneficiary beneficiary = beneficiaryRepository.findById(dto.getBeneficiaryId())
                .orElseThrow(() -> new BeneficiaryNotFoundException("Beneficiary not found with id: " + dto.getBeneficiaryId()));

        if (!beneficiary.getUser().getId().equals(user.getId())) {
            throw new InvalidRequestException("Beneficiary does not belong to the user");
        }

        // 4. Check balance
        if (fromAccount.getBalance().compareTo(dto.getAmount()) < 0) {
            throw new InsufficientBalanceException("Insufficient balance in account " + fromAccount.getAccountNumber());
        }

        // 5. Deduct balance
        fromAccount.setBalance(fromAccount.getBalance().subtract(dto.getAmount()));
        accountRepository.save(fromAccount);

        // 6. Create transaction
        Transaction transaction = new Transaction();
        transaction.setFromAccount(fromAccount);
        transaction.setToAccount(null); // external bank not stored
        transaction.setTransactionType(TransactionType.WITHDRAWAL);
        transaction.setAmount(dto.getAmount());
        transaction.setDescription(dto.getDescription());
        transaction.setStatus(TransactionStatus.SUCCESS);



        transactionRepository.save(transaction);


        return BeneficiaryTransferResponseDto.builder()
                .transactionId(transaction.getId())
                .beneficiaryName(beneficiary.getBeneficiaryName())
                .accountNumber(beneficiary.getAccountNumber())
                .bankName(beneficiary.getBankName())
                .amount(dto.getAmount())
                .status(transaction.getStatus().name())
                .createdAt(transaction.getCreatedAt() != null
                        ? LocalDateTime.ofInstant(transaction.getCreatedAt(), ZoneOffset.UTC)
                        : null)
                .build();

    }

//    public List<UserTransactionResponseDto> getTransactionsByFromAccount(String accountNumber) {
//        List<Transaction> transactions = transactionRepository.findByFromAccount_AccountNumber(accountNumber);
//
////        return transactions.stream()
////                .map(tx -> UserTransactionResponseDto.builder()
////                        .transactionId(tx.getId())
////                        .date(LocalDateTime.from(tx.getCreatedAt()))  // Assuming BaseEntity has createdAt
////                        .description(tx.getDescription())
////                        .type(tx.getTransactionType())
////                        .amount(tx.getAmount())
////                        .status(tx.getStatus())
////                        .build())
////                .collect(Collectors.toList());
//        return transactions.stream()
//                .map(tx -> UserTransactionResponseDto.builder()
//                        .transactionId(tx.getId())
//                        .date(LocalDateTime.ofInstant(tx.getCreatedAt(), ZoneId.systemDefault()))
//                        .description(tx.getDescription())
//                        .type(tx.getTransactionType())
//                        .amount(tx.getAmount())
//                        .status(tx.getStatus())
//                        .build())
//                .collect(Collectors.toList());
//
//    }

@Override
public List<UserTransactionResponseDto> getTransactionsByFromAccount(String accountNumber, TransactionSearchCriteria criteria) {
    List<Transaction> transactions = transactionRepository.findByFromAccount_AccountNumber(accountNumber);
//
//    return transactions.stream()
////            .filter(t -> criteria.getType() == null || t.getTransactionType().name().equalsIgnoreCase(criteria.getType()))
////            .filter(t -> criteria.getStatus() == null || t.getStatus().name().equalsIgnoreCase(criteria.getStatus()))
////            .filter(t -> {
////                if (criteria.getFromDate() == null && criteria.getToDate() == null) return true;
////
////                LocalDate date = t.getCreatedAt()
////                        .atZone(ZoneId.systemDefault())
////                        .toLocalDate();
////
////                LocalDate from = criteria.getFromDate() != null ? LocalDate.parse(criteria.getFromDate()) : LocalDate.MIN;
////                LocalDate to = criteria.getToDate() != null ? LocalDate.parse(criteria.getToDate()) : LocalDate.MAX;
////
////                return !date.isBefore(from) && !date.isAfter(to);
////            })
//            .map(tx -> UserTransactionResponseDto.builder()
//                    .transactionId(tx.getId())
//                    .date(LocalDateTime.ofInstant(tx.getCreatedAt(), ZoneId.systemDefault()))
//                    .description(tx.getDescription())
//                    .type(tx.getTransactionType())
//                    .amount(tx.getAmount())
//                    .status(tx.getStatus())
//                    .build())
//            .collect(Collectors.toList());

    String type = (criteria.getType() != null && !criteria.getType().isEmpty()) ? criteria.getType() : null;
    String status = (criteria.getStatus() != null && !criteria.getStatus().isEmpty()) ? criteria.getStatus() : null;

    return transactions.stream()
            .filter(t -> type == null || t.getTransactionType().name().equalsIgnoreCase(type))
            .filter(t -> status == null || t.getStatus().name().equalsIgnoreCase(status))
            .filter(t -> {
                if (criteria.getFromDate() == null && criteria.getToDate() == null) return true;

                LocalDate date = t.getCreatedAt()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();

                LocalDate from = criteria.getFromDate() != null && !criteria.getFromDate().isEmpty()
                        ? LocalDate.parse(criteria.getFromDate()) : LocalDate.MIN;

                LocalDate to = criteria.getToDate() != null && !criteria.getToDate().isEmpty()
                        ? LocalDate.parse(criteria.getToDate()) : LocalDate.MAX;

                return !date.isBefore(from) && !date.isAfter(to);
            })
            .map(tx -> UserTransactionResponseDto.builder()
                    .transactionId(tx.getId())
                    .date(LocalDateTime.ofInstant(tx.getCreatedAt(), ZoneId.systemDefault()))
                    .description(tx.getDescription())
                    .type(tx.getTransactionType())
                    .amount(tx.getAmount())
                    .status(tx.getStatus())
                    .build())
            .collect(Collectors.toList());
}


}
