package com.oracle.internetBanking.mapper;

import com.oracle.internetBanking.dto.request.BeneficiaryRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryResponseDto;
import com.oracle.internetBanking.entities.Beneficiary;

public class BeneficiaryMapper {

    public static Beneficiary toEntity(BeneficiaryRequestDto dto) {
        Beneficiary beneficiary = new Beneficiary();
        beneficiary.setBeneficiaryName(dto.getBeneficiaryName());
        beneficiary.setAccountNumber(dto.getAccountNumber());
        beneficiary.setBankName(dto.getBankName());
        beneficiary.setIfscCode(dto.getIfscCode());
        return beneficiary;
    }

    public static BeneficiaryResponseDto toDto(Beneficiary beneficiary) {
        return BeneficiaryResponseDto.builder()
                .id(beneficiary.getId())
                .beneficiaryName(beneficiary.getBeneficiaryName())
                .accountNumber(beneficiary.getAccountNumber())
                .bankName(beneficiary.getBankName())
                .ifscCode(beneficiary.getIfscCode())
                .userId(beneficiary.getUser().getId())
                .build();
    }
}
