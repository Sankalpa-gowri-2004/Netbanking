package com.oracle.internetBanking.entities;



import com.oracle.internetBanking.enums.PaymentFrequency;
import com.oracle.internetBanking.enums.PaymentStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "scheduled_payments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ScheduledPayment extends  BaseEntity {


    private String payee;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private PaymentFrequency frequency;

    private java.sql.Date nextRunDate;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status = PaymentStatus.ACTIVE;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "from_account_id", nullable = false)
    private Account fromAccount;

}
