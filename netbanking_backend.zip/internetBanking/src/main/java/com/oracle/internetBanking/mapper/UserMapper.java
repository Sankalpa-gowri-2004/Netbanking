package com.oracle.internetBanking.mapper;


import com.oracle.internetBanking.dto.request.UserSignUpRequestDto;
import com.oracle.internetBanking.dto.response.UserResponseDto;
import com.oracle.internetBanking.dto.response.UserSigninResponseDto;
import com.oracle.internetBanking.entities.User;

public class UserMapper {

    public static User toEntity(UserSignUpRequestDto userSignUpRequestDto){
        return  User.builder().email(userSignUpRequestDto.getEmail()).username(userSignUpRequestDto.getUsername()).password(userSignUpRequestDto.getPassword()).build();
    }

    public  static UserResponseDto toDto(String message) {
        return UserResponseDto.builder().success(true).message(message).build();
    }

    public static UserSigninResponseDto toDto(User user, String token) {
        return UserSigninResponseDto.builder().id(user.getId()).name(user.getUsername()).role(user.getRole()).email(user.getEmail()).token(token).success(true).build();
    }
}
