package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.AccountRequestDto;
import com.oracle.internetBanking.dto.request.TransactionFilterCriteria;
import com.oracle.internetBanking.dto.response.AccountResponseDto;
import com.oracle.internetBanking.dto.response.AccountSummaryDto;
import com.oracle.internetBanking.dto.response.DetailedUserDto;
import com.oracle.internetBanking.dto.response.MiniStatementDto;

import java.util.List;

public interface AccountService {
    AccountResponseDto createAccount(AccountRequestDto dto);
    List<AccountSummaryDto> getAccountsByUserId(Long userId);
    List<MiniStatementDto> getMiniStatement(Long accountId);
    List<MiniStatementDto> getFilteredTransactions(Long accountId, TransactionFilterCriteria filterCriteria);
    DetailedUserDto getDetailedInfo(Long accountId);
}
