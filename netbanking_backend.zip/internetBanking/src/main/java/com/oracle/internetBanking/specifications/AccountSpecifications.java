package com.oracle.internetBanking.specifications;


import com.oracle.internetBanking.entities.Account;
import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import org.springframework.data.jpa.domain.Specification;

public class AccountSpecifications {

    public static Specification<Account> hasType(AccountType type) {
        return (root, query, cb) ->
                type == null ? null : cb.equal(root.get("accountType"), type);
    }

    public static Specification<Account> hasStatus(AccountStatus status) {
        return (root, query, cb) ->
                status == null ? null : cb.equal(root.get("status"), status);
    }

    public static Specification<Account> hasBranch(String branchName) {
        return (root, query, cb) ->
                branchName == null ? null :
                        cb.equal(root.join("branch").get("branchName"), branchName);
    }

    public static Specification<Account> holderNameContains(String holderName) {
        return (root, query, cb) ->
                holderName == null ? null :
                        cb.like(cb.lower(root.join("user").get("username")), "%" + holderName.toLowerCase() + "%");
    }
}

