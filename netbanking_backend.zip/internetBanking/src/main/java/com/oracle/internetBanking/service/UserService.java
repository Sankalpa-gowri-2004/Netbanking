package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.UserSignInRequestDto;
import com.oracle.internetBanking.dto.request.OtpVerifyRequestDto;
import com.oracle.internetBanking.dto.request.UserSignUpRequestDto;
import com.oracle.internetBanking.dto.response.UserResponseDto;
import com.oracle.internetBanking.dto.response.UserSigninResponseDto;

public interface UserService {
    // existing
    UserResponseDto createUser(UserSignUpRequestDto request);

    // replace/extend existing getUser to "initiate" and "verify"
    void initiateLogin(UserSignInRequestDto request); // validates credentials, sends OTP
    UserSigninResponseDto verifyOtpAndLogin(OtpVerifyRequestDto request); // validate OTP, return token+user dto
}
