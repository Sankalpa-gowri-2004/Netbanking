package com.oracle.internetBanking.dto.request;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficiaryRequestDto {
    private Long userId;
    private String beneficiaryName;
    private String accountNumber;
    private String bankName;
    private String ifscCode;
}
