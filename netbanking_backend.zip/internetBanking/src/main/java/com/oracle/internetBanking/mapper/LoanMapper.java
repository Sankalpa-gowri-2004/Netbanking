package com.oracle.internetBanking.mapper;

import com.oracle.internetBanking.dto.request.LoanRequestDto;
import com.oracle.internetBanking.dto.response.LoanRepaymentDto;
import com.oracle.internetBanking.dto.response.LoanResponseDto;
import com.oracle.internetBanking.entities.Loan;
import com.oracle.internetBanking.entities.LoanRepayment;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class LoanMapper {

    public static Loan toEntity(LoanRequestDto dto) {
        Loan loan = new Loan();

        BigDecimal totalAmount = dto.getPrincipalAmount().add(
                dto.getPrincipalAmount().multiply(dto.getInterestRate()).multiply(BigDecimal.valueOf(dto.getTenureMonths()))
                        .divide(BigDecimal.valueOf(1200), 2, RoundingMode.HALF_UP)
        );

        loan.setRemainingAmount(totalAmount);
        loan.setLoanType(dto.getLoanType());
        loan.setPrincipalAmount(dto.getPrincipalAmount());
        loan.setInterestRate(dto.getInterestRate());
        loan.setTenureMonths(dto.getTenureMonths());
        loan.setStartDate(dto.getStartDate());
        return loan;
    }

    public static LoanResponseDto toDto(Loan loan) {
        return LoanResponseDto.builder()
                .id(loan.getId())
                .status(loan.getStatus())
                .loanType(loan.getLoanType())
                .principalAmount(loan.getPrincipalAmount())
                .interestRate(loan.getInterestRate())
                .tenureMonths(loan.getTenureMonths())
                .startDate(loan.getStartDate())
                .userId(loan.getUser().getId())
                .remainingAmount(loan.getRemainingAmount())
                .build();
    }

    public static LoanRepaymentDto toRepaymentDto(LoanRepayment repayment) {
        return LoanRepaymentDto.builder()
                .id(repayment.getId())
                .amountPaid(repayment.getAmountPaid())
                .paymentDate(repayment.getPaymentDate())
                .paymentMode(repayment.getPaymentMode())
                .build();
    }
}
