package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.request.BranchRequestDto;
import com.oracle.internetBanking.dto.response.BranchResponseDto;
import com.oracle.internetBanking.service.BranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/branches")
@RequiredArgsConstructor
public class BranchController {

    private final BranchService branchService;

    @PostMapping
    public ResponseEntity<BranchResponseDto> createBranch(@RequestBody BranchRequestDto dto) {
        return ResponseEntity.ok(branchService.createBranch(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BranchResponseDto> getBranchById(@PathVariable Long id) {
        return ResponseEntity.ok(branchService.getBranchById(id));
    }

    @GetMapping("/ifsc/{ifscCode}")
    public ResponseEntity<BranchResponseDto> getBranchByIfsc(@PathVariable String ifscCode) {
        return ResponseEntity.ok(branchService.getBranchByIfsc(ifscCode));
    }

    @GetMapping
    public ResponseEntity<List<BranchResponseDto>> getAllBranches() {
        return ResponseEntity.ok(branchService.getAllBranches());
    }



}

