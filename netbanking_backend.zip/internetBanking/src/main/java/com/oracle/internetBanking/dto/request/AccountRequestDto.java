package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.AccountType;
import lombok.Data;

@Data
public class AccountRequestDto {
    private Long userId;
    private AccountType accountType;
    private String currency;
    private String ifscCode;
}
