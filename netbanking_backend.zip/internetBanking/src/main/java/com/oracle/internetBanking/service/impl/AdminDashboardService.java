package com.oracle.internetBanking.service.impl;

/**
 * @author mirzbeg
 **/



import com.oracle.internetBanking.dto.request.*;
import com.oracle.internetBanking.dto.response.*;
import com.oracle.internetBanking.entities.*;
import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.enums.LoanStatus;
import com.oracle.internetBanking.mapper.BranchMapper;
import com.oracle.internetBanking.repository.*;
import com.oracle.internetBanking.specifications.AccountSpecifications;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AdminDashboardService {

    private final AccountRepository accountRepository;
    private final LoanRepository loanRepository;
    private final BranchRepository branchRepository;
    private final CardRepository cardRepository;
    private final UserRepository userRepository;

    public AdminDashboardResponse getDashboardData() {

        long totalAccounts = accountRepository.count();
        long totalLoans = loanRepository.count();
        long pendingApprovals = loanRepository.countByStatus(LoanStatus.PENDING);
        long totalBranches = branchRepository.count();

        Map<String, Double> loansPerBranch = new LinkedHashMap<>();
        List<Object[]> results = loanRepository.countLoansPerBranch();

        long totalLoansCount = results.stream()
                .mapToLong(r -> (Long) r[1])
                .sum();

        for (Object[] row : results) {
            String branch = (String) row[0];
            long count = (Long) row[1];
            double percentage = ((double) count / totalLoansCount) * 100;
            loansPerBranch.put(branch, Math.round(percentage * 100.0) / 100.0);
        }

        double sum = loansPerBranch.values().stream().mapToDouble(Double::doubleValue).sum();
        loansPerBranch.put("Others", Math.max(0, 100 - sum));
        return new AdminDashboardResponse(totalAccounts, totalLoans, pendingApprovals, totalBranches, loansPerBranch);
    }

    public  List<AccountResponse> getAccounts(AccountType type, String branch, AccountStatus status, String holderName) {
        Specification<Account> spec = Specification
                .where(AccountSpecifications.hasType(type))
                .and(AccountSpecifications.hasBranch(branch))
                .and(AccountSpecifications.hasStatus(status))
                .and(AccountSpecifications.holderNameContains(holderName));

        return accountRepository.findAll(spec).stream()
                .map(a -> new AccountResponse(
                        a.getAccountNumber(),
                        a.getUser().getUsername(),
                        a.getAccountType().name(),
                        a.getBranch().getBranchName(),
                        a.getStatus().name(),
                        a.getBalance()
                ))
                .toList();

    }

    public List<CardInfoDto> getAllCardInfo() {
        return cardRepository.findAllCardInfo();
    }

    public List<LoanInfoDto> getAllLoans() {
        return loanRepository.findAllLoanInfo();
    }



    public BranchResponseDto updateBranch(String ifscCode, BranchRequestDto dto) {
        Branch branch = branchRepository.findByIfscCode(ifscCode)
                .orElseThrow(() -> new RuntimeException("Branch not found with ID: " + ifscCode));

        // Only update fields that are non-null in DTO
        if (dto.getIfscCode() != null) {
            branch.setIfscCode(dto.getIfscCode());
        }
        if (dto.getBranchName() != null) {
            branch.setBranchName(dto.getBranchName());
        }
        if (dto.getAddress() != null) {
            branch.setAddress(dto.getAddress());
        }
        if (dto.getCity() != null) {
            branch.setCity(dto.getCity());
        }
        if (dto.getState() != null) {
            branch.setState(dto.getState());
        }
        if (dto.getContactNumber() != null) {
            branch.setContactNumber(dto.getContactNumber());
        }

        Branch updated = branchRepository.save(branch);

        return BranchMapper.toDto(updated);
    }


    @Transactional
    public AdminAccountReponse createAccount(AdminAccountDto dto) {

        Branch branch = branchRepository.findByBranchName(dto.getBranchName())
                .orElseThrow(() -> new RuntimeException("Branch not found: " + dto.getBranchName()));

        // 2. Find User by Username
        User user = userRepository.findByUsername(dto.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found: " + dto.getUsername()));

        // 3. Create new Account
        Account account = new Account();
        account.setBranch(branch);
        account.setUser(user);
        account.setAccountType(dto.getAccountType());
        account.setBalance(dto.getBalance() != null ? dto.getBalance() : BigDecimal.ZERO);
        account.setStatus(dto.getStatus() != null ? dto.getStatus() : AccountStatus.ACTIVE);
        account.setAccountNumber(dto.getAccountNumber());

        // 4. Save Account
        Account saved = accountRepository.save(account);
        System.out.println("I have save the account");
        // 5. Map response
        AdminAccountReponse response = AdminAccountReponse.builder().status(saved.getStatus()).accountNumber(saved.getAccountNumber()).accountType(saved.getAccountType()).balance(saved.getBalance()).username(saved.getUser().getUsername()).branchName(saved.getBranch().getBranchName()).build();
        System.out.println("About tp return the repsonse");
        return response;
    }

    @Transactional
    public AdminAccountReponse updateAccount(String accountNumber, AdminAccountDto dto) {

        // 1. Find the account
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found: " + accountNumber));

        // 2. Update fields if provided
        if (dto.getBranchName() != null) {
            Branch branch = branchRepository.findByBranchName(dto.getBranchName())
                    .orElseThrow(() -> new RuntimeException("Branch not found: " + dto.getBranchName()));
            account.setBranch(branch);
        }

        if (dto.getUsername() != null) {
            User user = userRepository.findByUsername(dto.getUsername())
                    .orElseThrow(() -> new RuntimeException("User not found: " + dto.getUsername()));
            account.setUser(user);
        }

        if (dto.getAccountType() != null) {
            account.setAccountType(dto.getAccountType());
        }

        if (dto.getBalance() != null) {
            account.setBalance(dto.getBalance());
        }

        if (dto.getStatus() != null) {
            account.setStatus(dto.getStatus());
        }

        // 3. Save updated entity
        Account updated = accountRepository.save(account);

        // 4. Build response DTO
        return AdminAccountReponse.builder()
                .id(updated.getId())
                .accountNumber(updated.getAccountNumber())
                .username(updated.getUser().getUsername())
                .branchName(updated.getBranch().getBranchName())
                .accountType(updated.getAccountType())
                .balance(updated.getBalance())
                .status(updated.getStatus())
                .build();
    }

    @Transactional
    public CardResponseDto updateCard(String cardNumber, CardUpdateRequestDto dto) {
        // 1️⃣ Find the card by card number
        Card card = cardRepository.findByCardNumber(cardNumber)
                .orElseThrow(() -> new RuntimeException("Card not found: " + cardNumber));

        // 2️⃣ Update fields if provided
        if (dto.getCardType() != null) {
            card.setCardType(dto.getCardType());
        }
        if (dto.getExpiryDate() != null) {
            card.setExpiryDate( dto.getExpiryDate());
        }
        if (dto.getStatus() != null) {
            card.setStatus(dto.getStatus());
        }

        if (dto.getUsername() != null) {
            User user = userRepository.findByUsername(dto.getUsername())
                    .orElseThrow(() -> new RuntimeException("User not found: " + dto.getUsername()));
            card.setUser(user);
        }

        if (dto.getAccountNumber() != null) {
            Account account = accountRepository.findByAccountNumber(dto.getAccountNumber())
                    .orElseThrow(() -> new RuntimeException("Account not found: " + dto.getAccountNumber()));
            card.setAccount(account);
        }

        // 3️⃣ Save updated card
        Card updated = cardRepository.save(card);

        // 4️⃣ Build and return response
        return CardResponseDto.builder()
                .cardNumber(updated.getCardNumber())
                .cardType(updated.getCardType())
                .expiryDate(updated.getExpiryDate().toLocalDate())
                .status(updated.getStatus())
                .cardId(updated.getId())
                .holder(updated.getUser().getUsername())
                .accountId(Long.valueOf(updated.getAccount().getAccountNumber()))
                .build();
    }

    @Transactional
    public LoanResponseDto updateLoan(Long id, LoanUpdateDto dto) {
        Loan loan = loanRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Loan not found with id: " + id));

        if (dto.getStatus() != null)
            loan.setStatus(dto.getStatus());
        if (dto.getPrincipalAmount() != null)
            loan.setPrincipalAmount(dto.getPrincipalAmount());
        if (dto.getInterestRate() != null)
            loan.setInterestRate(dto.getInterestRate());
        if (dto.getTenureMonths() != null)
            loan.setTenureMonths(dto.getTenureMonths());
        if (dto.getStartDate() != null)
            loan.setStartDate(dto.getStartDate());
        if (dto.getRemainingAmount() != null)
            loan.setRemainingAmount(dto.getRemainingAmount());

         loan=loanRepository.save(loan);

        LoanResponseDto response = LoanResponseDto.builder()
                .id(loan.getId())
                .status(loan.getStatus())
                .loanType(loan.getLoanType())
                .principalAmount(loan.getPrincipalAmount())
                .interestRate(loan.getInterestRate())
                .tenureMonths(loan.getTenureMonths())
                .startDate(loan.getStartDate())
                .userId(loan.getUser().getId())
                .remainingAmount(loan.getRemainingAmount())
                .build();
        return response;
    }
}

