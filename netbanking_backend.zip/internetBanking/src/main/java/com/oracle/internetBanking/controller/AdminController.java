package com.oracle.internetBanking.controller;

/**
 * @author mirzbeg
 **/



import com.oracle.internetBanking.dto.request.AdminAccountDto;
import com.oracle.internetBanking.dto.request.BranchRequestDto;
import com.oracle.internetBanking.dto.request.CardUpdateRequestDto;
import com.oracle.internetBanking.dto.request.LoanUpdateDto;
import com.oracle.internetBanking.dto.response.*;

import com.oracle.internetBanking.enums.AccountStatus;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.service.impl.AdminDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminDashboardService dashboardService;

    @GetMapping("/dashboard")
    public ResponseEntity<AdminDashboardResponse> getDashboardData() {
        return ResponseEntity.ok(dashboardService.getDashboardData());
    }


    @GetMapping ("/accounts")
    public List<AccountResponse> getAllAccounts(
            @RequestParam(required = false) AccountType type,
            @RequestParam(required = false) String branch,
            @RequestParam(required = false) AccountStatus status,
            @RequestParam(required = false) String holderName
    ) {
        return dashboardService.getAccounts(type, branch, status, holderName);
    }


    @GetMapping("/cards")
    public ResponseEntity<List<CardInfoDto>> getAllCards() {
        List<CardInfoDto> cards = dashboardService.getAllCardInfo();
        return ResponseEntity.ok(cards);
    }

    @GetMapping("/loans")
    public ResponseEntity<List<LoanInfoDto>> getAllLoans() {
        List<LoanInfoDto> loans = dashboardService.getAllLoans();
        return ResponseEntity.ok(loans);
    }

    @PatchMapping("/branch/{ifscCode}")
    public ResponseEntity<BranchResponseDto> updateBranch(
            @PathVariable String ifscCode,
            @RequestBody BranchRequestDto dto) {
        return ResponseEntity.ok(dashboardService.updateBranch(ifscCode, dto));
    }


    @PostMapping("/account")
    public ResponseEntity<AdminAccountReponse> createAccount(@RequestBody AdminAccountDto dto) {
        System.out.println("I am veign called");
        AdminAccountReponse adminAccountReponse= dashboardService.createAccount(dto);
        System.out.println("I am here after service call");
        System.out.println(adminAccountReponse.toString());
        return ResponseEntity.ok(adminAccountReponse);
    }

    @PatchMapping("/account/{accountNumber}")
    public ResponseEntity<AdminAccountReponse> updateAccount(
            @PathVariable String accountNumber,
            @RequestBody AdminAccountDto dto) {
        System.out.println("Updating account: " + accountNumber);
        AdminAccountReponse updatedAccount = dashboardService.updateAccount(accountNumber, dto);
        return ResponseEntity.ok(updatedAccount);
    }

    @PatchMapping("/card/{cardNumber}")
    public ResponseEntity<CardResponseDto> updateCard(
            @PathVariable String cardNumber,
            @RequestBody CardUpdateRequestDto dto) {
        CardResponseDto response = dashboardService.updateCard(cardNumber, dto);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/loan/{id}")
    public ResponseEntity<LoanResponseDto> updateLoan(
            @PathVariable Long id,
            @RequestBody LoanUpdateDto dto
    ) {
        LoanResponseDto updatedLoan = dashboardService.updateLoan(id, dto);
        return ResponseEntity.ok(updatedLoan);
    }
}

