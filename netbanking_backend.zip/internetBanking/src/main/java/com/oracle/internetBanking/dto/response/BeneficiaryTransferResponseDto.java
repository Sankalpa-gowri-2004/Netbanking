package com.oracle.internetBanking.dto.response;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficiaryTransferResponseDto {
    private Long transactionId;
    private String beneficiaryName;
    private String accountNumber;
    private String bankName;
    private BigDecimal amount;
    private String status;
    private LocalDateTime createdAt;
}
