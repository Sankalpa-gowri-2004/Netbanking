package com.oracle.internetBanking.enums;

public enum AccountType {
    SAVINGS, CURRENT, LOAN
}
