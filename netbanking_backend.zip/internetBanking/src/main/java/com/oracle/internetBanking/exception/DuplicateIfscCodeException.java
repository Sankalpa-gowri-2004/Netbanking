package com.oracle.internetBanking.exception;

public class DuplicateIfscCodeException extends RuntimeException {
    public DuplicateIfscCodeException(String message) {
        super(message);
    }
}
