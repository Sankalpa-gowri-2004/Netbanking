package com.oracle.internetBanking.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "branches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Branch extends BaseEntity {

    @Column(nullable = false, unique = true, length = 11)
    private String ifscCode;
    @Column(nullable = false)
    private String branchName;
    private String address;
    private String city;
    private String state;
    private String contactNumber;

}


