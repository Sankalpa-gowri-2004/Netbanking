package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.BranchRequestDto;
import com.oracle.internetBanking.dto.response.BranchResponseDto;
import com.oracle.internetBanking.entities.Branch;
import com.oracle.internetBanking.exception.BranchNotFoundException;
import com.oracle.internetBanking.exception.DuplicateIfscCodeException;
import com.oracle.internetBanking.mapper.BranchMapper;
import com.oracle.internetBanking.repository.BranchRepository;
import com.oracle.internetBanking.service.BranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BranchServiceImpl implements BranchService {

    private final BranchRepository branchRepository;

    @Override
    public BranchResponseDto createBranch(BranchRequestDto dto) {
        if (branchRepository.existsByIfscCode(dto.getIfscCode())) {
            throw new DuplicateIfscCodeException("Branch with IFSC code " + dto.getIfscCode() + " already exists");
        }

        Branch branch = BranchMapper.toEntity(dto);
        Branch saved = branchRepository.save(branch);
        return BranchMapper.toDto(saved);
    }

    @Override
    public BranchResponseDto getBranchById(Long id) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new BranchNotFoundException("Branch not found with ID: " + id));
        return BranchMapper.toDto(branch);
    }

    @Override
    public BranchResponseDto getBranchByIfsc(String ifscCode) {
        Branch branch = branchRepository.findByIfscCode(ifscCode)
                .orElseThrow(() -> new BranchNotFoundException("Branch not found with IFSC: " + ifscCode));
        return BranchMapper.toDto(branch);
    }

    @Override
    public List<BranchResponseDto> getAllBranches() {
        return branchRepository.findAll()
                .stream()
                .map(BranchMapper::toDto)
                .collect(Collectors.toList());
    }
}
