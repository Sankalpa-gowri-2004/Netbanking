package com.oracle.internetBanking.entities;


import com.oracle.internetBanking.enums.CardStatus;
import com.oracle.internetBanking.enums.CardType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "cards")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Card extends  BaseEntity {


    @Column(nullable = false, unique = true, length = 20)
    private String cardNumber;

    @Enumerated(EnumType.STRING)
    private CardType cardType;

    private java.sql.Date expiryDate;

    @Enumerated(EnumType.STRING)
    private CardStatus status = CardStatus.ACTIVE;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

}

