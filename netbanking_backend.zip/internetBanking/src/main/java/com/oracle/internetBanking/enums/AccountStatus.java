package com.oracle.internetBanking.enums;

public enum AccountStatus {
    ACTIVE, CLOSED, FROZEN
}