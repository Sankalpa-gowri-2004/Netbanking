package com.oracle.internetBanking.service;

import com.oracle.internetBanking.dto.request.BeneficiaryRequestDto;
import com.oracle.internetBanking.dto.response.BeneficiaryResponseDto;

import java.util.List;

public interface BeneficiaryService {
    BeneficiaryResponseDto addBeneficiary(BeneficiaryRequestDto dto);
    BeneficiaryResponseDto updateBeneficiary(Long id, BeneficiaryRequestDto dto);
    void deleteBeneficiary(Long id);
    BeneficiaryResponseDto getBeneficiary(Long id);
    List<BeneficiaryResponseDto> getUserBeneficiaries(Long userId);
}
