package com.oracle.internetBanking.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OtpResponseDto {
    private String message;
    private Boolean success;
}
