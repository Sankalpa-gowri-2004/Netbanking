package com.oracle.internetBanking.enums;

public enum CardType {
    DEBIT, CREDIT
}
