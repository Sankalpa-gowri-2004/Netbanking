package com.oracle.internetBanking.mapper;

import com.oracle.internetBanking.dto.response.CardResponseDto;
import com.oracle.internetBanking.entities.Card;

public class CardMapper {
    public static CardResponseDto toDto(Card card) {
        return CardResponseDto.builder()
                .cardId(card.getId())
                .cardNumber(card.getCardNumber())
                .cardType(card.getCardType())
                .expiryDate(card.getExpiryDate().toLocalDate())
                .status(card.getStatus())
                .userId(card.getUser().getId())
                .accountId(card.getAccount().getId())
                .holder(card.getUser().getUsername())
                .build();
    }
}
