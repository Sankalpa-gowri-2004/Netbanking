package com.oracle.internetBanking.utils;


import com.oracle.internetBanking.entities.User;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtil {

    public static User getCurrentUser() {
        return (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    public static void validateOwnership(User owner) {
        User current = getCurrentUser();
//        if (!current.getId().equals(owner.getId())) {
//            throw new UnauthorizedAccessException("You are not the owner of this event");
//        }
    }
}
