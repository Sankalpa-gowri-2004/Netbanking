package com.oracle.internetBanking.dto.request;

import com.oracle.internetBanking.enums.CardType;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CardRequestDto {
    private CardType cardType;
}
