package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.dto.request.UserSignUpRequestDto;
import com.oracle.internetBanking.dto.request.UserSignInRequestDto;
import com.oracle.internetBanking.dto.request.OtpVerifyRequestDto;
import com.oracle.internetBanking.dto.response.UserResponseDto;
import com.oracle.internetBanking.dto.response.UserSigninResponseDto;
import com.oracle.internetBanking.entities.Account;
import com.oracle.internetBanking.entities.Branch;
import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.enums.AccountType;
import com.oracle.internetBanking.enums.Role;
import com.oracle.internetBanking.exception.DuplicateUserException;
import com.oracle.internetBanking.exception.InvalidCredentialsException;
import com.oracle.internetBanking.exception.UserNotFoundException;
import com.oracle.internetBanking.mapper.UserMapper;
import com.oracle.internetBanking.repository.AccountRepository;
import com.oracle.internetBanking.repository.BranchRepository;
import com.oracle.internetBanking.repository.UserRepository;
import com.oracle.internetBanking.service.OtpService;
import com.oracle.internetBanking.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;
    private final OtpService otpService;
    private final AccountRepository accountRepository;
    private final BranchRepository branchRepository;


    @Override
    @Transactional
    public UserResponseDto createUser(UserSignUpRequestDto userSignUpRequestDto) {
        log.info("Creating user with username: {}", userSignUpRequestDto.getUsername());

        if (userRepository.findByUsername(userSignUpRequestDto.getUsername()).isPresent()) {
            throw new DuplicateUserException("Username already exists");
        }

        // 1. Save user
        User user = UserMapper.toEntity(userSignUpRequestDto);
        user.setRole(Role.CUSTOMER);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);


        // 2. Getting default branch
        if (branchRepository.count() == 0) {
            throw new RuntimeException("No branches available. Please create a branch first.");
        }
        Branch branch=branchRepository.findByIfscCode("BANK0000001").orElseThrow(()->new RuntimeException("Default branch not found"));

        // 3. Auto-create default savings account
        Account account = new Account();
        account.setUser(user);
        account.setAccountType(AccountType.SAVINGS);
        account.setAccountNumber(generateAccountNumber());
        account.setBalance(BigDecimal.valueOf(0.0));
        account.setCurrency("INR");
        account.setBranch(branch);
        accountRepository.save(account);

        // 3. Generate token and return DTO
//        String token = jwtService.generateToken(user);
        return UserMapper.toDto("User is Signed Up Successfully,Please Login to Enjoy Our Banking Services");

    }

    private String generateAccountNumber() {
        // Simple 12-digit random number (you can improve with branch codes, etc.)
        return String.valueOf(System.currentTimeMillis()).substring(0, 12);
    }


    /**
     * Step 1: Validate username/password. If OK, generate & send OTP to the user's registered email.
     * DO NOT return token here.
     */
    @Override
    @Transactional
    public void initiateLogin(UserSignInRequestDto userSignInRequestDto) {

        User user = userRepository.findByEmail(userSignInRequestDto.getEmail())
                .orElseThrow(() -> new UserNotFoundException("User not found.."));

        if (!passwordEncoder.matches(userSignInRequestDto.getPassword(), user.getPassword())) {
            throw new InvalidCredentialsException("Incorrect password");
        }

        // we use email for OTP destination
        String email = user.getEmail();
        otpService.generateAndSendOtpForLogin(email);
    }

    /**
     * Step 2: Validate OTP. If valid, return UserResponseDto with JWT token.
     */
    @Override
    @Transactional
    public UserSigninResponseDto verifyOtpAndLogin(OtpVerifyRequestDto dto) {
        // accept either username or email in dto
        String identifier = dto.getEmail();

        User user = userRepository.findByEmail(identifier).orElseThrow(() -> new UserNotFoundException("User not found"));


        // validate OTP for user's email
        otpService.validateOtpAndMarkUsed(user.getEmail(), dto.getOtp());


        String token = jwtService.generateToken(user);
        return UserMapper.toDto(user, token);
    }
}
