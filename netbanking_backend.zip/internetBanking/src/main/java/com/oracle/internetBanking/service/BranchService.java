package com.oracle.internetBanking.service;


import com.oracle.internetBanking.dto.request.BranchRequestDto;
import com.oracle.internetBanking.dto.response.BranchResponseDto;

import java.util.List;

public interface BranchService {
    BranchResponseDto createBranch(BranchRequestDto dto);
    BranchResponseDto getBranchById(Long id);
    BranchResponseDto getBranchByIfsc(String ifscCode);
    List<BranchResponseDto> getAllBranches();
}

