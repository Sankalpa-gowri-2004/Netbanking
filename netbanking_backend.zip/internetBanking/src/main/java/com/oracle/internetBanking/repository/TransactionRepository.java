package com.oracle.internetBanking.repository;

import com.oracle.internetBanking.entities.Account;
import com.oracle.internetBanking.entities.Transaction;
import com.oracle.internetBanking.enums.TransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findTop10ByFromAccountOrToAccountOrderByCreatedAtDesc(Account from, Account to);
    List<Transaction> findByFromAccountOrToAccount(Account from, Account to);
    List<Transaction> findByFromAccountOrToAccountAndCreatedAtBetween(
            Account from, Account to, LocalDateTime start, LocalDateTime end);
    List<Transaction> findByFromAccountOrToAccountAndTransactionType(
            Account from, Account to, TransactionType type);

    List<Transaction> findByFromAccount_AccountNumber(String accountNumber);
}
