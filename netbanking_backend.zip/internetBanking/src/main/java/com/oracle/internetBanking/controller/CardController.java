package com.oracle.internetBanking.controller;

import com.oracle.internetBanking.dto.request.CardRequestDto;
import com.oracle.internetBanking.dto.response.CardResponseDto;
import com.oracle.internetBanking.service.CardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/cards")
@RequiredArgsConstructor
public class CardController {

    private final CardService cardService;

    @GetMapping("/{userId}")
    public ResponseEntity<List<CardResponseDto>> getActiveCards(@PathVariable Long userId) {
        return ResponseEntity.ok(cardService.getActiveCards(userId));
    }

    @PostMapping("/block/{cardId}")
    public ResponseEntity<CardResponseDto> blockCard(@PathVariable String cardId) {
        return ResponseEntity.ok(cardService.blockCard(cardId));
    }

    @PostMapping("/request/{userId}")
    public ResponseEntity<CardResponseDto> requestNewCard(
            @PathVariable Long userId,
            @RequestBody CardRequestDto dto) {
        log.info("Requesting new card for user ID: {}", userId);

        return ResponseEntity.ok(cardService.requestNewCard(userId, dto));
    }
}
