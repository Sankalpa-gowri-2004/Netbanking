package com.oracle.internetBanking.dto.response;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionResponseDto {
    private Long transactionId;
    private Long fromAccountId;
    private Long toAccountId;
    private String transactionType;
    private BigDecimal amount;
    private String description;
    private String status;
    private LocalDateTime createdAt;
}

