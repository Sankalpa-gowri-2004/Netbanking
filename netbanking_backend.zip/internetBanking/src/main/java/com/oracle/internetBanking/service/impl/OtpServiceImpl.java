package com.oracle.internetBanking.service.impl;

import com.oracle.internetBanking.entities.User;
import com.oracle.internetBanking.entities.UserOtp;
import com.oracle.internetBanking.exception.OtpAlreadyUsedException;
import com.oracle.internetBanking.exception.OtpExpiredException;
import com.oracle.internetBanking.exception.OtpNotFoundException;
import com.oracle.internetBanking.repository.OtpRepository;
import com.oracle.internetBanking.repository.UserRepository;
import com.oracle.internetBanking.service.EmailService;
import com.oracle.internetBanking.service.OtpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OtpServiceImpl implements OtpService {

    private final OtpRepository otpRepository;
    private final EmailService emailService;
    private final UserRepository userRepository;

    // configure expiry and length as constants (can be externalized)
    private static final int OTP_EXPIRY_MINUTES = 5;
    private static final int OTP_LENGTH = 6;

    private final SecureRandom secureRandom = new SecureRandom();

    @Override
    @Transactional
    public void generateAndSendOtpForLogin(String email) {
        // Optional: check rate limit (e.g. last OTP created < 60s => reject). Not implemented here; can be added.
        String otp = generateNumericOtp(OTP_LENGTH);
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(OTP_EXPIRY_MINUTES);

        UserOtp userOtp = UserOtp.builder()
                .email(email)
                .otp(otp)
                .expiryTime(expiry)
                .used(false)
                .createdAt(LocalDateTime.now())
                .build();

        otpRepository.save(userOtp);

        // send email
        emailService.sendOtpEmail(email, otp, OTP_EXPIRY_MINUTES);
        log.info("Sent OTP to {}", email);
    }

    @Override
    @Transactional
    public String validateOtpAndMarkUsed(String email, String otp) {
        Optional<UserOtp> maybe = otpRepository.findFirstByEmailAndOtpAndUsedFalse(email, otp);
        UserOtp userOtp = maybe.orElseThrow(() -> new OtpNotFoundException("Invalid OTP"));

        if (userOtp.isUsed()) {
            throw new OtpAlreadyUsedException("OTP already used");
        }

        if (userOtp.getExpiryTime().isBefore(LocalDateTime.now())) {
            throw new OtpExpiredException("OTP expired");
        }

        // mark used
        userOtp.setUsed(true);
        otpRepository.save(userOtp);

        // return email (or user id) as verification success
        return userOtp.getEmail();
    }

    private String generateNumericOtp(int length) {
        int min = (int) Math.pow(10, length - 1);
        int max = (int) Math.pow(10, length) - 1;
        int number = secureRandom.nextInt((max - min) + 1) + min;
        return String.valueOf(number);
    }
}
