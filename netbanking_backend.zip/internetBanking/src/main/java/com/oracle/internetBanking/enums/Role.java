package com.oracle.internetBanking.enums;

public enum Role {
    CUSTOMER, ADMIN, STAFF
}
