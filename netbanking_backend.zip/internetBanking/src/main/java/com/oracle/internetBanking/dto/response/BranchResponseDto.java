package com.oracle.internetBanking.dto.response;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchResponseDto {
    private Long id;
    private String ifscCode;
    private String branchName;
    private String address;
    private String city;
    private String state;
    private String contactNumber;
}
