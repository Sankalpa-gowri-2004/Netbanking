package com.oracle.internetBanking.enums;

public enum PaymentFrequency {
    DAILY, WEEKLY, MONTHLY
}
